import type { ModelForecast } from "../lib/stockEngine";
import { Cpu, Award } from "lucide-react";

interface Props {
  forecasts: ModelForecast[];
  selected: string;
  onSelect: (name: string) => void;
}

export default function ModelComparison({ forecasts, selected, onSelect }: Props) {
  const best = [...forecasts].sort((a, b) => b.metrics.R2 - a.metrics.R2)[0];
  const maxRMSE = Math.max(...forecasts.map((f) => f.metrics.RMSE));

  return (
    <div className="card p-4 fade-in">
      <div className="flex items-center gap-2 mb-3">
        <Cpu className="w-4 h-4 text-teal-400" />
        <h3 className="text-sm font-bold text-slate-200">Model Performance Lab</h3>
        <span className="pill ml-auto">{forecasts.length} models trained</span>
      </div>

      <div className="overflow-x-auto -mx-4">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-slate-500 text-[10px] uppercase tracking-widest border-b border-[#1f2942]">
              <th className="py-2 px-4 text-left font-semibold">Model</th>
              <th className="py-2 text-left font-semibold">Type</th>
              <th className="py-2 text-right font-semibold">MAE</th>
              <th className="py-2 text-right font-semibold">RMSE</th>
              <th className="py-2 text-right font-semibold">R² Score</th>
              <th className="py-2 text-right font-semibold">Confidence</th>
              <th className="py-2 px-4 text-right font-semibold"></th>
            </tr>
          </thead>
          <tbody>
            {forecasts.map((f) => {
              const isBest = f.name === best.name;
              const isSelected = f.name === selected;
              return (
                <tr key={f.name}
                    onClick={() => onSelect(f.name)}
                    className={
                      "border-b border-[#1f2942] cursor-pointer transition-colors " +
                      (isSelected ? "bg-[#1a2138]" : "hover:bg-[#131a2c]")
                    }>
                  <td className="py-2.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-sm" style={{ background: f.color }} />
                      <span className="font-semibold text-slate-200">{f.name}</span>
                      {isBest && <Award className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </td>
                  <td className="py-2.5">
                    <span className={
                      "pill text-[9px] " +
                      (f.family === "DL" ? "text-teal-400 border-teal-500/30"
                       : f.family === "ML" ? "text-indigo-400 border-indigo-500/30"
                       : "text-amber-400 border-amber-500/30")
                    }>{f.family}</span>
                  </td>
                  <td className="py-2.5 text-right tabular-nums text-slate-300">{f.metrics.MAE}</td>
                  <td className="py-2.5 text-right tabular-nums">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-16 h-1 rounded-full bg-[#1f2942] overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-teal-400 to-indigo-400"
                             style={{ width: `${100 - (f.metrics.RMSE / maxRMSE) * 100}%` }} />
                      </div>
                      <span className="text-slate-300">{f.metrics.RMSE}</span>
                    </div>
                  </td>
                  <td className={"py-2.5 text-right tabular-nums font-bold " + (f.metrics.R2 > 0.7 ? "text-bull" : f.metrics.R2 > 0.4 ? "text-amber-400" : "text-bear")}>
                    {f.metrics.R2.toFixed(3)}
                  </td>
                  <td className="py-2.5 text-right tabular-nums text-slate-300">{(f.confidence * 100).toFixed(0)}%</td>
                  <td className="py-2.5 px-4 text-right">
                    <button className="text-[10px] px-2 py-1 rounded border border-[#1f2942] text-teal-400 hover:bg-teal-500/10">
                      {isSelected ? "ACTIVE" : "USE"}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-3 text-[11px] text-slate-500 flex items-center gap-3 flex-wrap">
        <span><Award className="w-3 h-3 inline text-amber-400" /> Best performer by R² (trained on 80% / validated on 20%)</span>
        <span>· Metrics: MAE, MSE, RMSE, R² Score</span>
      </div>
    </div>
  );
}
