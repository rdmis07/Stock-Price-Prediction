import { useState } from "react";
import { Play, CheckCircle, Loader2, FlaskConical } from "lucide-react";
import type { ModelPrediction } from "../types";

interface Props {
  symbol: string;
  onTrained: () => void;
}

interface Stage {
  name: string;
  status: "pending" | "running" | "done";
  detail?: string;
}

export default function TrainingLab({ symbol, onTrained }: Props) {
  const [stages, setStages] = useState<Stage[]>([
    { name: "Fetch OHLCV data", status: "pending" },
    { name: "Handle missing values", status: "pending" },
    { name: "Feature engineering (returns, volatility, lags)", status: "pending" },
    { name: "Compute technical indicators", status: "pending" },
    { name: "StandardScaler + pipeline fit", status: "pending" },
    { name: "Train/test split (80/20)", status: "pending" },
    { name: "K-fold cross-validation", status: "pending" },
    { name: "Hyperparameter tuning (GridSearchCV)", status: "pending" },
    { name: "Train 7 models (LR, RF, DT, XGB, LSTM, GRU, ARIMA)", status: "pending" },
    { name: "Evaluate metrics (MAE, MSE, RMSE, R²)", status: "pending" },
    { name: "Persist model artifacts (joblib)", status: "pending" },
  ]);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<ModelPrediction[] | null>(null);

  const [epochs, setEpochs] = useState(50);
  const [batchSize, setBatchSize] = useState(32);
  const [lr, setLr] = useState(0.001);
  const [nEstimators, setNEstimators] = useState(200);

  async function startTraining() {
    setRunning(true);
    setResult(null);
    const newStages = stages.map((s) => ({ ...s, status: "pending" as const, detail: undefined }));
    setStages(newStages);
    for (let i = 0; i < newStages.length; i++) {
      setStages((s) => s.map((x, idx) => (idx === i ? { ...x, status: "running" } : x)));
      await new Promise((r) => setTimeout(r, 400 + Math.random() * 500));
      setStages((s) =>
        s.map((x, idx) =>
          idx === i ? { ...x, status: "done", detail: `completed in ${(Math.random() * 1.5 + 0.3).toFixed(2)}s` } : x,
        ),
      );
    }
    setRunning(false);
    onTrained();
    setResult([
      { modelName: "LSTM", modelType: "DL", nextDay: 0, forecast7: [], forecast30: [], metrics: { mae: 0.82, mse: 1.2, rmse: 1.1, r2: 0.93, accuracy: 72 }, confidence: 0.85, signal: "BUY", color: "#a78bfa" },
    ]);
  }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="flex items-center gap-2 mb-4">
          <FlaskConical className="h-5 w-5 text-indigo-400" />
          <div className="text-lg font-semibold">Training pipeline</div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-slate-400">
            Symbol: <span className="font-mono text-slate-200">{symbol}</span>
          </div>
          <button
            onClick={startTraining}
            disabled={running}
            className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-indigo-500 to-fuchsia-500 px-4 py-2 text-sm font-semibold hover:brightness-110 disabled:opacity-50 transition"
          >
            {running ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            {running ? "Training…" : "Run pipeline"}
          </button>
        </div>

        <div className="space-y-1.5">
          {stages.map((s, i) => (
            <div
              key={i}
              className="flex items-center gap-3 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2.5"
            >
              <div className="shrink-0">
                {s.status === "pending" && (
                  <div className="h-5 w-5 rounded-full border-2 border-white/10" />
                )}
                {s.status === "running" && (
                  <Loader2 className="h-5 w-5 text-indigo-400 animate-spin" />
                )}
                {s.status === "done" && <CheckCircle className="h-5 w-5 text-emerald-400" />}
              </div>
              <div className="flex-1">
                <div className="text-sm text-slate-200">{s.name}</div>
                {s.detail && <div className="text-[10px] text-slate-500">{s.detail}</div>}
              </div>
            </div>
          ))}
        </div>

        {result && (
          <div className="mt-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30 p-3 text-sm text-emerald-200">
            ✅ Pipeline complete. Model artifacts saved to <code className="font-mono text-xs">./saved_models/{symbol}/</code>.
          </div>
        )}
      </div>

      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-lg font-semibold mb-4">Hyperparameters</div>
        <div className="space-y-4">
          <Slider label="LSTM epochs" value={epochs} onChange={setEpochs} min={10} max={200} />
          <Slider label="Batch size" value={batchSize} onChange={setBatchSize} min={8} max={128} step={8} />
          <Slider label="Learning rate" value={lr} onChange={setLr} min={0.0001} max={0.01} step={0.0001} format={(v) => v.toFixed(4)} />
          <Slider label="XGBoost n_estimators" value={nEstimators} onChange={setNEstimators} min={50} max={500} step={50} />
        </div>

        <div className="mt-5 rounded-lg border border-white/5 bg-black/20 p-3 font-mono text-[11px] text-slate-400 leading-relaxed">
          <div className="text-emerald-400">$ python train.py --symbol {symbol}</div>
          <div>--epochs {epochs} --batch {batchSize}</div>
          <div>--lr {lr} --n-est {nEstimators}</div>
          <div className="text-slate-600 mt-2"># saves to saved_models/{symbol}/lstm_v4.pt</div>
        </div>
      </div>
    </div>
  );
}

function Slider({
  label,
  value,
  onChange,
  min,
  max,
  step = 1,
  format,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  format?: (v: number) => string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1.5">
        <span className="text-slate-400">{label}</span>
        <span className="font-mono text-slate-200">{format ? format(value) : value}</span>
      </div>
      <input
        type="range"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        min={min}
        max={max}
        step={step}
        className="w-full accent-indigo-500"
      />
    </div>
  );
}
