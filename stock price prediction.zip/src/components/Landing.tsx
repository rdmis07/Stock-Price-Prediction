import { motion } from "framer-motion";
import {
  TrendingUp,
  Sparkles,
  Brain,
  LineChart,
  ShieldCheck,
  Zap,
  Activity,
  BarChart3,
  ArrowRight,
  Check,
  Code2,
  AtSign,
  Briefcase,
} from "lucide-react";

interface Props {
  onGetStarted: () => void;
}

export default function Landing({ onGetStarted }: Props) {
  const features = [
    {
      icon: Brain,
      title: "8 AI Models",
      desc: "Linear Regression, Random Forest, XGBoost, LSTM, GRU, ARIMA, Prophet, and Decision Tree — ranked by R² in real time.",
      color: "from-indigo-500 to-violet-500",
    },
    {
      icon: LineChart,
      title: "7 Technical Indicators",
      desc: "SMA, EMA, RSI, MACD, Bollinger Bands, Volatility, and Momentum computed on every bar.",
      color: "from-fuchsia-500 to-pink-500",
    },
    {
      icon: Activity,
      title: "Live Market Data",
      desc: "Real-time OHLCV streaming for NASDAQ, NYSE, NSE, and BSE via Yahoo Finance.",
      color: "from-emerald-500 to-teal-500",
    },
    {
      icon: Sparkles,
      title: "AI Sentiment Fusion",
      desc: "FinBERT news sentiment blended with price signals for bias-corrected forecasts.",
      color: "from-amber-500 to-orange-500",
    },
    {
      icon: BarChart3,
      title: "Interactive Dashboards",
      desc: "Candlesticks, prediction bands, model arena, portfolio P&L, and multi-stock comparison.",
      color: "from-cyan-500 to-sky-500",
    },
    {
      icon: ShieldCheck,
      title: "Production-Grade API",
      desc: "FastAPI + JWT + SQLAlchemy + Docker. Swagger docs, async routes, CI/CD pipelines included.",
      color: "from-rose-500 to-red-500",
    },
  ];

  const stats = [
    { value: "8", label: "AI Models" },
    { value: "15+", label: "Tickers" },
    { value: "94%", label: "Avg R² Score" },
    { value: "<200ms", label: "Prediction Latency" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-100 overflow-hidden relative">
      {/* Background effects */}
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(99,102,241,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-indigo-600/20 rounded-full blur-3xl" />
      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-fuchsia-600/15 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-3xl" />

      {/* Navbar */}
      <header className="relative z-10 border-b border-white/5 backdrop-blur-xl bg-[#0a0e1a]/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="font-bold tracking-tight text-lg">StockOracle AI</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-widest">v4.3 · Pro</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm text-slate-300">
            <a href="#features" className="hover:text-white transition">Features</a>
            <a href="#models" className="hover:text-white transition">Models</a>
            <a href="#pricing" className="hover:text-white transition">Pricing</a>
            <a href="#docs" className="hover:text-white transition">Docs</a>
          </nav>
          <button
            onClick={onGetStarted}
            className="rounded-lg bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:brightness-110 px-5 py-2 text-sm font-semibold shadow-lg shadow-indigo-500/30 transition"
          >
            Launch App →
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-4 py-1.5 text-xs text-indigo-300 mb-8"
        >
          <Sparkles className="h-3.5 w-3.5" />
          New · Prophet forecasting + AI chatbot assistant · v4.3
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]"
        >
          The AI copilot for
          <br />
          <span className="bg-gradient-to-r from-indigo-400 via-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
            stock market alpha.
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 text-lg text-slate-400 max-w-2xl mx-auto"
        >
          Ensemble of 8 machine learning models, 7 technical indicators, and FinBERT news
          sentiment — fused into a single probabilistic forecast. Built with FastAPI,
          TensorFlow, and React.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <button
            onClick={onGetStarted}
            className="rounded-xl bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:brightness-110 px-6 py-3 font-semibold shadow-xl shadow-indigo-500/30 transition flex items-center gap-2"
          >
            Start Predicting Free
            <ArrowRight className="h-4 w-4" />
          </button>
          <a
            href="#features"
            className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-6 py-3 font-semibold transition"
          >
            See the platform
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-16 relative max-w-5xl mx-auto"
        >
          <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/30 via-fuchsia-500/30 to-emerald-500/30 blur-3xl rounded-3xl" />
          <div className="relative rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl p-2 shadow-2xl">
            <div className="rounded-xl bg-[#070a14] overflow-hidden">
              <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-white/5">
                <div className="h-2.5 w-2.5 rounded-full bg-rose-500/70" />
                <div className="h-2.5 w-2.5 rounded-full bg-amber-500/70" />
                <div className="h-2.5 w-2.5 rounded-full bg-emerald-500/70" />
                <div className="ml-3 text-[10px] text-slate-500 font-mono">
                  stockoracle.ai/dashboard · AAPL
                </div>
              </div>
              {/* Simulated dashboard preview */}
              <div className="grid grid-cols-4 gap-3 p-4">
                {[
                  { label: "NVDA", val: "$892.40", chg: "+2.4%" },
                  { label: "AAPL", val: "$187.25", chg: "+0.8%" },
                  { label: "TSLA", val: "$252.18", chg: "-1.2%" },
                  { label: "MSFT", val: "$418.90", chg: "+1.1%" },
                ].map((t) => (
                  <div
                    key={t.label}
                    className="rounded-lg bg-white/[0.03] border border-white/5 p-3 text-left"
                  >
                    <div className="text-[10px] text-slate-500 font-mono">{t.label}</div>
                    <div className="text-sm font-bold mt-0.5">{t.val}</div>
                    <div
                      className={
                        "text-[10px] font-semibold " +
                        (t.chg.startsWith("+") ? "text-emerald-400" : "text-rose-400")
                      }
                    >
                      {t.chg}
                    </div>
                  </div>
                ))}
              </div>
              {/* Fake chart */}
              <div className="h-48 mx-4 mb-4 rounded-lg bg-gradient-to-b from-indigo-500/10 to-transparent border border-white/5 relative overflow-hidden">
                <svg viewBox="0 0 400 150" className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#818cf8" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#818cf8" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M0,100 L20,90 L40,95 L60,70 L80,75 L100,55 L120,60 L140,45 L160,50 L180,35 L200,40 L220,30 L240,35 L260,25 L280,30 L300,20 L320,25 L340,15 L360,22 L380,10 L400,18 L400,150 L0,150 Z"
                    fill="url(#g)"
                  />
                  <path
                    d="M0,100 L20,90 L40,95 L60,70 L80,75 L100,55 L120,60 L140,45 L160,50 L180,35 L200,40 L220,30 L240,35 L260,25 L280,30 L300,20 L320,25 L340,15 L360,22 L380,10 L400,18"
                    stroke="#818cf8"
                    strokeWidth="2"
                    fill="none"
                  />
                </svg>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + i * 0.1 }}
              className="rounded-xl border border-white/5 bg-white/[0.02] p-5"
            >
              <div className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-fuchsia-400 bg-clip-text text-transparent">
                {s.value}
              </div>
              <div className="text-xs text-slate-500 mt-1">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <div className="text-xs uppercase tracking-widest text-indigo-400 font-semibold mb-3">
            The Platform
          </div>
          <h2 className="text-4xl font-bold tracking-tight">Everything you need to forecast alpha</h2>
          <p className="text-slate-400 mt-3 max-w-xl mx-auto">
            A complete AI stack for retail traders, quants, and portfolio managers.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="group rounded-2xl border border-white/5 bg-white/[0.02] p-6 hover:border-white/10 hover:bg-white/[0.04] transition"
            >
              <div
                className={
                  "h-11 w-11 rounded-xl bg-gradient-to-br " +
                  f.color +
                  " flex items-center justify-center shadow-lg"
                }
              >
                <f.icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="mt-4 font-semibold text-lg">{f.title}</h3>
              <p className="mt-1.5 text-sm text-slate-400 leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Models */}
      <section id="models" className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <div className="text-xs uppercase tracking-widest text-fuchsia-400 font-semibold mb-3">
            Model Arena
          </div>
          <h2 className="text-4xl font-bold tracking-tight">8 models. One ensemble forecast.</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { name: "Linear Regression", type: "ML", color: "#60a5fa" },
            { name: "Random Forest", type: "ML", color: "#34d399" },
            { name: "Decision Tree", type: "ML", color: "#fbbf24" },
            { name: "XGBoost", type: "ML", color: "#f472b6" },
            { name: "LSTM", type: "Deep Learning", color: "#a78bfa" },
            { name: "GRU", type: "Deep Learning", color: "#c084fc" },
            { name: "ARIMA", type: "Statistical", color: "#fb7185" },
            { name: "Prophet", type: "Statistical", color: "#22d3ee" },
          ].map((m) => (
            <div
              key={m.name}
              className="rounded-xl border border-white/5 bg-white/[0.02] p-4 hover:border-white/10 transition"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: m.color }} />
                <span className="text-[10px] uppercase tracking-wider text-slate-500">
                  {m.type}
                </span>
              </div>
              <div className="font-semibold">{m.name}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold mb-3">
            Pricing
          </div>
          <h2 className="text-4xl font-bold tracking-tight">Start free, scale when you need</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-4 max-w-5xl mx-auto">
          {[
            {
              name: "Starter",
              price: "$0",
              features: ["3 tickers", "1D forecast", "4 ML models", "Community support"],
              cta: "Get started",
              highlight: false,
            },
            {
              name: "Pro",
              price: "$29",
              period: "/mo",
              features: [
                "Unlimited tickers",
                "30-day forecast",
                "All 8 models",
                "AI chatbot",
                "PDF reports",
                "Priority support",
              ],
              cta: "Start Pro trial",
              highlight: true,
            },
            {
              name: "Enterprise",
              price: "Custom",
              features: [
                "Self-hosted deployment",
                "Custom models",
                "Webhook alerts",
                "SSO / SAML",
                "Dedicated SLA",
              ],
              cta: "Contact sales",
              highlight: false,
            },
          ].map((p) => (
            <div
              key={p.name}
              className={
                "rounded-2xl p-6 relative " +
                (p.highlight
                  ? "border border-indigo-400/40 bg-gradient-to-b from-indigo-500/10 to-fuchsia-500/5 shadow-xl shadow-indigo-500/10"
                  : "border border-white/5 bg-white/[0.02]")
              }
            >
              {p.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                  Most popular
                </div>
              )}
              <div className="text-sm font-semibold text-slate-300">{p.name}</div>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-4xl font-bold">{p.price}</span>
                {p.period && <span className="text-sm text-slate-500">{p.period}</span>}
              </div>
              <ul className="mt-6 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-slate-300">
                    <Check className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={onGetStarted}
                className={
                  "mt-6 w-full rounded-lg py-2.5 text-sm font-semibold transition " +
                  (p.highlight
                    ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:brightness-110"
                    : "border border-white/10 bg-white/5 hover:bg-white/10")
                }
              >
                {p.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section id="docs" className="relative z-10 max-w-5xl mx-auto px-6 py-20">
        <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-indigo-500/10 via-violet-500/5 to-fuchsia-500/10 p-12 text-center relative overflow-hidden">
          <div className="absolute -top-20 -right-20 h-64 w-64 bg-indigo-500/20 rounded-full blur-3xl" />
          <div className="absolute -bottom-20 -left-20 h-64 w-64 bg-fuchsia-500/20 rounded-full blur-3xl" />
          <div className="relative">
            <Zap className="h-10 w-10 text-indigo-400 mx-auto mb-4" />
            <h2 className="text-4xl font-bold tracking-tight">Ready to forecast alpha?</h2>
            <p className="text-slate-400 mt-3 max-w-xl mx-auto">
              Join thousands of traders and quants using StockOracle AI to make
              data-driven decisions.
            </p>
            <button
              onClick={onGetStarted}
              className="mt-8 rounded-xl bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:brightness-110 px-8 py-3 font-semibold shadow-xl shadow-indigo-500/30 transition flex items-center gap-2 mx-auto"
            >
              Launch App
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold">StockOracle AI</span>
            <span className="text-xs text-slate-500">· v4.3</span>
          </div>
          <div className="text-xs text-slate-500">
            © 2026 StockOracle AI · For research & educational purposes. Not financial advice.
          </div>
          <div className="flex items-center gap-3">
            {[Code2, AtSign, Briefcase].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="h-9 w-9 rounded-lg border border-white/5 bg-white/[0.02] hover:bg-white/10 flex items-center justify-center transition"
              >
                <Icon className="h-4 w-4 text-slate-400" />
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
