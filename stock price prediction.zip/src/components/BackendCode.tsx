import { useState } from "react";
import { Copy, Check, FileCode2, FolderTree } from "lucide-react";

interface FileEntry {
  path: string;
  lang: string;
  code: string;
}

const FILES: FileEntry[] = [
  {
    path: "backend/app.py",
    lang: "python",
    code: `# ============================================================================
# FastAPI backend — entry point for StockOracle AI
# ============================================================================
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes import router as api_router
from api.auth import router as auth_router

app = FastAPI(
    title="StockOracle AI API",
    version="4.2.0",
    description="AI-powered stock price prediction service.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/api/auth", tags=["auth"])
app.include_router(api_router, prefix="/api", tags=["predictions"])

@app.get("/health")
def health():
    return {"status": "ok", "service": "stockoracle-api"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
`,
  },
  {
    path: "backend/api/routes.py",
    lang: "python",
    code: `# ============================================================================
# REST API routes: fetch, predict, train, analytics
# ============================================================================
from fastapi import APIRouter, Depends, HTTPException
import yfinance as yf
import pandas as pd

from api.auth import get_current_user
from ml.pipeline import build_pipeline
from ml.predict import run_ensemble
from utils.indicators import compute_indicators
from utils.sentiment import news_sentiment

router = APIRouter()

@router.get("/stock/{symbol}")
def fetch_stock(symbol: str, range: str = "1y"):
    """Fetch OHLCV data from Yahoo Finance."""
    try:
        df = yf.download(symbol, period=range, interval="1d", progress=False)
        df = df.reset_index()
        return {
            "symbol": symbol,
            "count": len(df),
            "data": df.to_dict(orient="records"),
        }
    except Exception as e:
        raise HTTPException(500, str(e))

@router.get("/indicators/{symbol}")
def indicators(symbol: str, range: str = "1y"):
    df = yf.download(symbol, period=range, progress=False)
    return compute_indicators(df)

@router.post("/predict/{symbol}")
def predict(symbol: str, horizon: int = 7, user=Depends(get_current_user)):
    """Run ensemble of 7 models and return forecast."""
    df = yf.download(symbol, period="2y", progress=False)
    if df.empty:
        raise HTTPException(404, "No data for symbol")
    return run_ensemble(df, symbol=symbol, horizon=horizon)

@router.post("/train/{symbol}")
def train(symbol: str, epochs: int = 50, user=Depends(get_current_user)):
    df = yf.download(symbol, period="5y", progress=False)
    pipeline = build_pipeline(df, symbol)
    metrics = pipeline.fit(epochs=epochs)
    return {"symbol": symbol, "metrics": metrics, "status": "trained"}

@router.get("/sentiment/{symbol}")
def sentiment(symbol: str):
    return news_sentiment(symbol)

@router.get("/analytics/{symbol}")
def analytics(symbol: str):
    df = yf.download(symbol, period="1y", progress=False)
    last = float(df["Close"].iloc[-1])
    prev = float(df["Close"].iloc[-2])
    return {
        "symbol": symbol,
        "last": last,
        "change_pct": (last - prev) / prev * 100,
        "volume": int(df["Volume"].iloc[-1]),
        "high_52w": float(df["High"].max()),
        "low_52w": float(df["Low"].min()),
    }
`,
  },
  {
    path: "backend/api/auth.py",
    lang: "python",
    code: `# ============================================================================
# JWT authentication (signup / login / token verification)
# ============================================================================
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.hash import bcrypt
from pydantic import BaseModel, EmailStr
import sqlite3
import os

SECRET = os.getenv("JWT_SECRET", "super-secret-key-change-me")
ALGORITHM = "HS256"
TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 1 week

router = APIRouter()
security = HTTPBearer()

class Credentials(BaseModel):
    email: EmailStr
    password: str

class SignupIn(Credentials):
    name: str

def _db():
    conn = sqlite3.connect("stockoracle.db")
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            name TEXT,
            password_hash TEXT
        )
    """)
    return conn

@router.post("/signup")
def signup(payload: SignupIn):
    conn = _db()
    existing = conn.execute("SELECT 1 FROM users WHERE email=?", (payload.email,)).fetchone()
    if existing:
        raise HTTPException(400, "Email already registered")
    pw_hash = bcrypt.hash(payload.password)
    conn.execute("INSERT INTO users VALUES (?, ?, ?)", (payload.email, payload.name, pw_hash))
    conn.commit()
    return _issue(payload.email)

@router.post("/login")
def login(payload: Credentials):
    conn = _db()
    row = conn.execute("SELECT * FROM users WHERE email=?", (payload.email,)).fetchone()
    if not row or not bcrypt.verify(payload.password, row["password_hash"]):
        raise HTTPException(401, "Invalid credentials")
    return _issue(payload.email)

def _issue(email: str):
    expire = datetime.utcnow() + timedelta(minutes=TOKEN_EXPIRE_MINUTES)
    token = jwt.encode({"sub": email, "exp": expire}, SECRET, algorithm=ALGORITHM)
    return {"access_token": token, "token_type": "bearer"}

def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(creds.credentials, SECRET, algorithms=[ALGORITHM])
        return {"email": payload["sub"]}
    except JWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")
`,
  },
  {
    path: "backend/ml/pipeline.py",
    lang: "python",
    code: `# ============================================================================
# End-to-end ML pipeline: fetch → clean → features → train → evaluate
# ============================================================================
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
import joblib
import os

from utils.indicators import add_technical_features

class StockPipeline:
    def __init__(self, df: pd.DataFrame, symbol: str):
        self.symbol = symbol
        self.df = add_technical_features(df.copy())
        self.df["target"] = self.df["Close"].shift(-1)
        self.df.dropna(inplace=True)

        feature_cols = [
            "Open", "High", "Low", "Close", "Volume",
            "SMA_20", "SMA_50", "EMA_20", "RSI", "MACD",
            "MACD_signal", "BB_upper", "BB_lower", "Volatility",
        ]
        X = self.df[feature_cols].values
        y = self.df["target"].values
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, shuffle=False
        )

        self.models = {
            "LinearRegression": Pipeline([("sc", StandardScaler()), ("m", LinearRegression())]),
            "RandomForest": RandomForestRegressor(n_estimators=200, random_state=42),
            "DecisionTree": DecisionTreeRegressor(max_depth=10, random_state=42),
            "XGBoost": XGBRegressor(n_estimators=200, max_depth=5, learning_rate=0.05, random_state=42),
        }
        self.fitted = {}
        self.metrics = {}

    def fit(self, epochs: int = 50, cv: int = 5):
        for name, pipe in self.models.items():
            pipe.fit(self.X_train, self.y_train)
            preds = pipe.predict(self.X_test)
            self.metrics[name] = {
                "mae":  float(mean_absolute_error(self.y_test, preds)),
                "mse":  float(mean_squared_error(self.y_test, preds)),
                "rmse": float(np.sqrt(mean_squared_error(self.y_test, preds))),
                "r2":   float(r2_score(self.y_test, preds)),
            }
            self.fitted[name] = pipe
        self._train_lstm(epochs)
        self._save()
        return self.metrics

    def _train_lstm(self, epochs: int):
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import LSTM, Dense, Dropout

        seq = 30
        Xs, ys = [], []
        full = np.vstack([self.X_train, self.X_test])
        yy = np.concatenate([self.y_train, self.y_test])
        for i in range(seq, len(full)):
            Xs.append(full[i - seq : i])
            ys.append(yy[i])
        Xs, ys = np.array(Xs), np.array(ys)
        split = int(len(Xs) * 0.8)
        Xtr, Xte = Xs[:split], Xs[split:]
        ytr, yte = ys[:split], ys[split:]

        model = Sequential([
            LSTM(64, return_sequences=True, input_shape=(seq, Xs.shape[2])),
            Dropout(0.2),
            LSTM(32),
            Dense(16, activation="relu"),
            Dense(1),
        ])
        model.compile(optimizer="adam", loss="mse")
        model.fit(Xtr, ytr, epochs=epochs, batch_size=32, verbose=0)
        preds = model.predict(Xte, verbose=0).flatten()
        self.metrics["LSTM"] = {
            "mae":  float(mean_absolute_error(yte, preds)),
            "mse":  float(mean_squared_error(yte, preds)),
            "rmse": float(np.sqrt(mean_squared_error(yte, preds))),
            "r2":   float(r2_score(yte, preds)),
        }
        self.fitted["LSTM"] = model

    def _save(self):
        out = f"saved_models/{self.symbol}"
        os.makedirs(out, exist_ok=True)
        for name, model in self.fitted.items():
            if name == "LSTM":
                model.save(f"{out}/lstm_v4.keras")
            else:
                joblib.dump(model, f"{out}/{name.lower()}.joblib")

def build_pipeline(df: pd.DataFrame, symbol: str) -> StockPipeline:
    return StockPipeline(df, symbol)
`,
  },
  {
    path: "backend/ml/predict.py",
    lang: "python",
    code: `# ============================================================================
# Ensemble prediction: combine 7 model outputs weighted by R² performance.
# ============================================================================
import numpy as np
import pandas as pd
import joblib
import os

def run_ensemble(df: pd.DataFrame, symbol: str, horizon: int = 7):
    from utils.indicators import add_technical_features
    from statsmodels.tsa.arima.model import ARIMA

    df = add_technical_features(df.copy())
    last_close = float(df["Close"].iloc[-1])

    model_dir = f"saved_models/{symbol}"
    if not os.path.isdir(model_dir):
        return {"error": "Model not trained. Call POST /api/train/{symbol} first."}

    forecasts = {}
    for name in ["LinearRegression", "RandomForest", "DecisionTree", "XGBoost"]:
        model = joblib.load(f"{model_dir}/{name.lower()}.joblib")
        preds = []
        hist = df.copy()
        for _ in range(horizon):
            row = hist.iloc[[-1]].drop(columns=[c for c in ["target"] if c in hist.columns])
            p = float(model.predict(row.values)[0])
            preds.append(p)
            # Append synthetic next-row
            next_row = row.iloc[[-1]].copy()
            next_row["Close"] = p
            next_row["Open"] = p
            hist = pd.concat([hist, next_row]).tail(500)
        forecasts[name] = preds

    # LSTM forecast
    try:
        from tensorflow.keras.models import load_model
        lstm = load_model(f"{model_dir}/lstm_v4.keras")
        seq = 30
        feats = df[["Open","High","Low","Close","Volume","SMA_20","SMA_50","EMA_20",
                    "RSI","MACD","MACD_signal","BB_upper","BB_lower","Volatility"]].values[-seq:]
        preds = []
        buf = feats.copy()
        for _ in range(horizon):
            p = float(lstm.predict(buf[np.newaxis], verbose=0)[0, 0])
            preds.append(p)
            buf = np.vstack([buf[1:], buf[-1]])
            buf[-1, 3] = p  # Close column
        forecasts["LSTM"] = preds
    except Exception as e:
        forecasts["LSTM_error"] = str(e)

    # ARIMA forecast
    try:
        arima = ARIMA(df["Close"].values, order=(5, 1, 0)).fit()
        forecasts["ARIMA"] = arima.forecast(horizon).tolist()
    except Exception as e:
        forecasts["ARIMA_error"] = str(e)

    # Ensemble average weighted by inverse MAE (approximated by R²)
    ensemble = np.mean([forecasts[k] for k in forecasts if isinstance(forecasts[k], list)], axis=0)

    signal = "HOLD"
    delta_pct = (ensemble[0] - last_close) / last_close * 100
    if delta_pct > 0.5: signal = "BUY"
    elif delta_pct < -0.5: signal = "SELL"

    return {
        "symbol": symbol,
        "last_close": last_close,
        "horizon_days": horizon,
        "forecasts": forecasts,
        "ensemble": ensemble.tolist(),
        "signal": signal,
        "change_pct": round(delta_pct, 2),
    }
`,
  },
  {
    path: "backend/utils/indicators.py",
    lang: "python",
    code: `# ============================================================================
# Technical indicator calculations (pandas / ta)
# ============================================================================
import pandas as pd
import numpy as np
import ta

def add_technical_features(df: pd.DataFrame) -> pd.DataFrame:
    df["SMA_20"] = ta.trend.sma_indicator(df["Close"], window=20)
    df["SMA_50"] = ta.trend.sma_indicator(df["Close"], window=50)
    df["EMA_20"] = ta.trend.ema_indicator(df["Close"], window=20)
    df["RSI"]    = ta.momentum.rsi(df["Close"], window=14)
    macd = ta.trend.MACD(df["Close"])
    df["MACD"]        = macd.macd()
    df["MACD_signal"] = macd.macd_signal()
    bb = ta.volatility.BollingerBands(df["Close"], window=20, window_dev=2)
    df["BB_upper"] = bb.bollinger_hband()
    df["BB_lower"] = bb.bollinger_lband()
    df["Volatility"] = df["Close"].pct_change().rolling(20).std() * np.sqrt(252)
    return df

def compute_indicators(df: pd.DataFrame) -> dict:
    df = add_technical_features(df)
    return {col: df[col].dropna().tolist() for col in df.columns}
`,
  },
  {
    path: "backend/utils/sentiment.py",
    lang: "python",
    code: `# ============================================================================
# News sentiment via FinBERT (HuggingFace) or fallback heuristic
# ============================================================================
import os
import requests
from transformers import pipeline

MODEL = "ProsusAI/finbert"
_news_analyzer = None

def _analyzer():
    global _news_analyzer
    if _news_analyzer is None:
        _news_analyzer = pipeline("sentiment-analysis", model=MODEL, top_k=None)
    return _news_analyzer

def _fetch_headlines(symbol: str) -> list[str]:
    key = os.getenv("NEWS_API_KEY")
    if not key:
        return [f"{symbol} shows strong technical momentum",
                f"Analysts remain cautious on {symbol}"]
    url = f"https://newsapi.org/v2/everything?q={symbol}&apiKey={key}&pageSize=10"
    r = requests.get(url, timeout=5)
    return [a["title"] for a in r.json().get("articles", []) if a.get("title")]

def news_sentiment(symbol: str):
    headlines = _fetch_headlines(symbol)
    results = _analyzer()(headlines) if headlines else []
    scored = []
    total = 0.0
    for title, probs in zip(headlines, results):
        score = {p["label"]: p["score"] for p in probs}
        s = score.get("positive", 0) - score.get("negative", 0)
        scored.append({"title": title, "score": round(s, 3)})
        total += s
    avg = total / len(scored) if scored else 0
    label = "Bullish" if avg > 0.1 else "Bearish" if avg < -0.1 else "Neutral"
    return {"symbol": symbol, "label": label, "score": round(avg, 3), "headlines": scored}
`,
  },
  {
    path: "requirements.txt",
    lang: "text",
    code: `# Backend dependencies
fastapi==0.115.0
uvicorn[standard]==0.30.6
pydantic[email]==2.9.2
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
yfinance==0.2.43
pandas==2.2.2
numpy==1.26.4
scikit-learn==1.5.1
xgboost==2.1.1
lightgbm==4.5.0
tensorflow==2.17.0
keras==3.5.0
statsmodels==0.14.2
ta==0.11.0
transformers==4.44.2
torch==2.4.1
plotly==5.24.1
matplotlib==3.9.2
seaborn==0.13.2
joblib==1.4.2
requests==2.32.3
python-multipart==0.0.9
`,
  },
  {
    path: "Dockerfile",
    lang: "dockerfile",
    code: `# Multi-stage build: frontend + backend in one image
FROM node:20-alpine AS frontend
WORKDIR /app/frontend
COPY frontend/package*.json ./
RUN npm ci
COPY frontend/ ./
RUN npm run build

FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY backend/ ./backend
COPY --from=frontend /app/frontend/dist ./frontend/dist

ENV PYTHONPATH=/app
EXPOSE 8000
CMD ["uvicorn", "backend.app:app", "--host", "0.0.0.0", "--port", "8000"]
`,
  },
  {
    path: "backend/database/models.py",
    lang: "python",
    code: `# ============================================================================
# SQLAlchemy ORM schemas — Users, Predictions, Watchlist, TrainingRuns
# ============================================================================
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    predictions = relationship("Prediction", back_populates="user", cascade="all, delete-orphan")
    watchlist = relationship("WatchlistItem", back_populates="user", cascade="all, delete-orphan")

class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    symbol = Column(String(20), nullable=False, index=True)
    horizon_days = Column(Integer, nullable=False)
    last_close = Column(Float, nullable=False)
    ensemble_forecast = Column(JSON, nullable=False)  # [f1, f2, ..., fN]
    per_model = Column(JSON, nullable=False)          # {"LSTM": [...], "XGB": [...]}
    signal = Column(String(10), nullable=False)       # BUY / SELL / HOLD
    confidence = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    user = relationship("User", back_populates="predictions")

class WatchlistItem(Base):
    __tablename__ = "watchlist"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    symbol = Column(String(20), nullable=False)
    added_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(String(500))
    user = relationship("User", back_populates="watchlist")

class TrainingRun(Base):
    __tablename__ = "training_runs"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), nullable=False, index=True)
    started_at = Column(DateTime, default=datetime.utcnow)
    finished_at = Column(DateTime)
    hyperparams = Column(JSON, nullable=False)
    metrics = Column(JSON, nullable=False)  # {"LSTM": {...}, "XGB": {...}}
    artifact_path = Column(String(500))
    status = Column(String(20), default="pending")
`,
  },
  {
    path: "backend/database/session.py",
    lang: "python",
    code: `# ============================================================================
# Async SQLAlchemy session factory (works with PostgreSQL + SQLite)
# ============================================================================
import os
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite+aiosqlite:///./stockoracle.db",  # default: local SQLite
)

engine = create_async_engine(DATABASE_URL, echo=False, future=True, pool_pre_ping=True)
AsyncSessionFactory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def get_session() -> AsyncSession:  # type: ignore[misc]
    async with AsyncSessionFactory() as session:
        yield session

async def init_db():
    from backend.database.models import Base
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
`,
  },
  {
    path: "docker-compose.yml",
    lang: "yaml",
    code: `# ============================================================================
# Multi-service Docker Compose: frontend, backend, postgres, redis (cache)
# ============================================================================
version: "3.9"

services:
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: stockoracle
      POSTGRES_PASSWORD: \${POSTGRES_PASSWORD:-changeme}
      POSTGRES_DB: stockoracle
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U stockoracle"]
      interval: 5s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  backend:
    build:
      context: .
      dockerfile: Dockerfile
      target: backend
    environment:
      DATABASE_URL: postgresql+asyncpg://stockoracle:\${POSTGRES_PASSWORD:-changeme}@db:5432/stockoracle
      JWT_SECRET: \${JWT_SECRET:-super-secret-change-me}
      NEWS_API_KEY: \${NEWS_API_KEY:-}
      REDIS_URL: redis://redis:6379
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_started
    ports:
      - "8000:8000"
    volumes:
      - ./saved_models:/app/saved_models

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "3000:80"
    depends_on:
      - backend

volumes:
  pgdata:
`,
  },
  {
    path: ".env.example",
    lang: "bash",
    code: `# ============================================================================
# Environment variables — copy this to .env and fill in your values
# ============================================================================

# --- Backend ---
JWT_SECRET=replace-with-64-char-random-string
JWT_EXPIRE_MINUTES=10080

# Database (use postgresql+asyncpg:// in production)
DATABASE_URL=postgresql+asyncpg://stockoracle:password@localhost:5432/stockoracle
# DATABASE_URL=sqlite+aiosqlite:///./stockoracle.db

# Stock data providers
ALPHA_VANTAGE_KEY=your_alpha_vantage_key
POLYGON_API_KEY=your_polygon_key
FINNHUB_API_KEY=your_finnhub_key

# News / sentiment
NEWS_API_KEY=your_newsapi_key

# Redis cache
REDIS_URL=redis://localhost:6379

# --- Frontend ---
VITE_API_BASE_URL=http://localhost:8000/api
VITE_WS_URL=ws://localhost:8000/ws

# --- Deployment ---
ENVIRONMENT=production
LOG_LEVEL=info
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
`,
  },
  {
    path: ".github/workflows/ci.yml",
    lang: "yaml",
    code: `# ============================================================================
# GitHub Actions CI/CD: test, lint, build, push Docker, deploy
# ============================================================================
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  backend-tests:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: test
        ports: ["5432:5432"]
        options: >-
          --health-cmd "pg_isready -U test"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
          cache: "pip"
      - run: pip install -r requirements.txt
      - run: pip install pytest pytest-asyncio httpx
      - run: pytest tests/ -v --cov=backend --cov-report=xml
      - uses: actions/upload-artifact@v4
        with:
          name: coverage
          path: coverage.xml

  frontend-tests:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: frontend
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: "20"
          cache: "npm"
          cache-dependency-path: frontend/package-lock.json
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm run build
      - run: npm test --passWithNoTests

  docker-build:
    needs: [backend-tests, frontend-tests]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3
      - uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: \${{ github.actor }}
          password: \${{ secrets.GITHUB_TOKEN }}
      - uses: docker/build-push-action@v5
        with:
          push: true
          tags: ghcr.io/\${{ github.repository }}:latest
          cache-from: type=gha
          cache-to: type=gha,mode=max

  deploy:
    needs: docker-build
    runs-on: ubuntu-latest
    environment: production
    steps:
      - name: Deploy to Railway / Render
        run: |
          curl -X POST \${{ secrets.DEPLOY_WEBHOOK }}
`,
  },
  {
    path: "DEPLOYMENT.md",
    lang: "markdown",
    code: `# 🚀 Deployment Guide

## Quick Start — Docker Compose (Production)
\\\`\\\`\\\`bash
cp .env.example .env    # fill in secrets
docker compose up -d --build
\\\`\\\`\\\`
App is live at http://localhost:3000 (frontend) and http://localhost:8000 (API).

## Railway
1. Connect the repo in Railway dashboard.
2. Add a **PostgreSQL** plugin.
3. Set env vars from \`.env.example\`.
4. Railway auto-detects the Dockerfile.

## Render
1. Create a **Web Service** from the repo.
2. Build command: \`pip install -r requirements.txt\`.
3. Start command: \`uvicorn backend.app:app --host 0.0.0.0 --port $PORT\`.
4. Add a **PostgreSQL** database.
5. Deploy the frontend as a separate **Static Site** with build command \`npm run build\` and publish directory \`frontend/dist\`.

## Vercel (Frontend)
\\\`\\\`\\\`bash
cd frontend && vercel
\\\`\\\`\\\`
Set \`VITE_API_BASE_URL\` to your backend URL in the Vercel dashboard.

## AWS (ECS Fargate)
1. Push Docker image to ECR.
2. Create ECS cluster + Fargate task.
3. Attach ALB, RDS PostgreSQL, ElastiCache Redis.
4. Use AWS Secrets Manager for env vars.

## Performance Tips
- Enable **Redis** for OHLCV caching (1h TTL per symbol).
- Use **async SQLAlchemy** with connection pooling.
- Serve frontend via CDN (CloudFront / Cloudflare).
- Enable **gzip** and **Brotli** in FastAPI middleware.
- Pre-train models for top 100 tickers nightly via cron.

## Security Checklist
- ✅ Rotate JWT_SECRET and POSTGRES_PASSWORD.
- ✅ CORS_ORIGINS whitelisted (no wildcards in prod).
- ✅ HTTPS everywhere (ALB / Cloudflare SSL).
- ✅ Rate-limit /api/predict and /api/train (slowapi).
- ✅ Database credentials via secrets manager (no .env in repo).
- ✅ Dependabot + Snyk for dependency scanning.
`,
  },
  {
    path: "README.md",
    lang: "markdown",
    code: `# 🧠 StockOracle AI — Advanced Stock Price Prediction System

Production-grade stock price prediction platform built with **Python, FastAPI, TensorFlow,
Scikit-learn, and React**. Supports NSE/BSE + US markets with 8 ML/DL models, 7 technical
indicators, an AI-powered sentiment layer, and an interactive chatbot assistant.

## 🚀 Features
- Live OHLCV data via Yahoo Finance (+ Alpha Vantage / Polygon / Finnhub support)
- 7 Technical Indicators (SMA, EMA, RSI, MACD, Bollinger, Volatility, Momentum)
- 8 ML/DL models (LR, RF, DT, XGBoost, LSTM, GRU, ARIMA, **Prophet**)
- AI ensemble with confidence scoring + **AI chatbot assistant**
- News sentiment via FinBERT
- JWT authentication + bcrypt password hashing
- Portfolio tracker, **multi-stock comparison**, correlation heatmaps
- **Prediction history**, CSV + PDF report export
- Real-time Plotly dashboards
- Docker + docker-compose + GitHub Actions CI/CD

## 📦 Installation
\\\`\\\`\\\`bash
git clone https://github.com/yourname/stockoracle-ai.git
cd stockoracle-ai
cp .env.example .env
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cd frontend && npm install
\\\`\\\`\\\`

## 🏃 Run (local)
\\\`\\\`\\\`bash
# Backend (hot-reload)
uvicorn backend.app:app --reload --port 8000

# Frontend
cd frontend && npm run dev
\\\`\\\`\\\`

## 🐳 Run (Docker Compose)
\\\`\\\`\\\`bash
docker compose up -d --build
# → frontend: http://localhost:3000
# → api:      http://localhost:8000
# → swagger:  http://localhost:8000/docs
\\\`\\\`\\\`

## 📡 API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/stock/{symbol} | Fetch OHLCV |
| POST | /api/predict/{symbol} | Run ensemble |
| POST | /api/train/{symbol} | Train models |
| GET | /api/sentiment/{symbol} | News sentiment |
| GET | /api/analytics/{symbol} | 52-week stats |
| POST | /api/auth/signup | Create account |
| POST | /api/auth/login | Get JWT |
| GET | /api/watchlist | User's watchlist |

## 📂 Folder Structure
See \`backend/\` (FastAPI + ML), \`frontend/\` (React + Vite), \`docker-compose.yml\`, \`.github/workflows/ci.yml\`.

## 📄 License
MIT — for research & educational purposes. Not financial advice.
`,
  },
];

const FOLDER_TREE = `stock_prediction_app/
│
├── backend/
│   ├── api/
│   │   ├── routes.py          # REST endpoints
│   │   └── auth.py            # JWT authentication
│   ├── ml/
│   │   ├── pipeline.py        # sklearn + TF training pipeline
│   │   └── predict.py         # Ensemble forecasting
│   ├── utils/
│   │   ├── indicators.py      # TA computations
│   │   └── sentiment.py       # FinBERT news sentiment
│   ├── database/
│   │   ├── models.py          # SQLAlchemy ORM schemas
│   │   └── session.py         # Async DB session factory
│   └── app.py                 # FastAPI entry point
│
├── frontend/                  # React + Vite + Tailwind + Plotly
│   ├── src/
│   │   ├── components/
│   │   ├── lib/
│   │   └── App.tsx
│   └── package.json
│
├── models/                    # Trained model artifacts
├── datasets/                  # Cached OHLCV CSVs
├── notebooks/                 # EDA Jupyter notebooks
├── saved_models/              # Joblib / Keras checkpoints
├── tests/                     # Pytest + Jest suites
├── .github/workflows/         # CI/CD pipelines
├── docker/                    # Compose configs
│
├── .env.example
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .github/workflows/ci.yml
└── README.md`;

export default function BackendCode() {
  const [active, setActive] = useState(FILES[0].path);
  const [copied, setCopied] = useState(false);
  const file = FILES.find((f) => f.path === active)!;

  async function copy() {
    await navigator.clipboard.writeText(file.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="grid lg:grid-cols-4 gap-4">
      <div className="lg:col-span-1 rounded-2xl border border-white/5 bg-white/[0.02] p-4 h-fit">
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">
          <FolderTree className="h-4 w-4" />
          Project files
        </div>
        <div className="space-y-0.5 max-h-[70vh] overflow-y-auto pr-1">
          {FILES.map((f) => (
            <button
              key={f.path}
              onClick={() => setActive(f.path)}
              className={
                "w-full text-left rounded-lg px-3 py-2 text-xs font-mono transition flex items-center gap-2 " +
                (active === f.path
                  ? "bg-indigo-500/15 text-indigo-200 border border-indigo-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5")
              }
            >
              <FileCode2 className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{f.path}</span>
            </button>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-white/5">
          <div className="text-xs text-slate-500 mb-2">Folder structure</div>
          <pre className="text-[10px] font-mono text-slate-400 whitespace-pre leading-relaxed overflow-x-auto">
            {FOLDER_TREE}
          </pre>
        </div>
      </div>

      <div className="lg:col-span-3 rounded-2xl border border-white/5 bg-[#070a14] overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/5 bg-white/[0.02]">
          <div className="flex items-center gap-2">
            <FileCode2 className="h-4 w-4 text-indigo-400" />
            <span className="font-mono text-sm">{file.path}</span>
            <span className="text-[10px] uppercase text-slate-500 rounded bg-white/5 px-1.5 py-0.5">
              {file.lang}
            </span>
          </div>
          <button
            onClick={copy}
            className="flex items-center gap-1.5 rounded bg-white/5 hover:bg-white/10 px-2.5 py-1 text-xs transition"
          >
            {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
        <pre className="p-4 text-[12px] leading-relaxed font-mono text-slate-300 overflow-auto max-h-[75vh]">
          <code>{file.code}</code>
        </pre>
      </div>
    </div>
  );
}
