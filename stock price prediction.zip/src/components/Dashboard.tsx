import { useMemo, useState } from "react";
import type { StockCandle, TimeRange } from "../types";
import { computeAllIndicators } from "../lib/indicators";
import { runAllModels, ensembleInsight } from "../lib/models";
import { generateSentiment } from "../lib/sentiment";
import CandlestickChart from "../components/CandlestickChart";
import TechnicalCharts from "../components/TechnicalCharts";
import StatCards from "../components/StatCards";
import AIInsights from "../components/AIInsights";

interface Props {
  candles: StockCandle[];
  symbol: string;
  range: TimeRange;
  onRangeChange: (r: TimeRange) => void;
  onNavigate: (v: "models" | "forecast") => void;
}

export default function Dashboard({ candles, symbol, range, onRangeChange, onNavigate }: Props) {
  const [showTechnicals, setShowTechnicals] = useState(true);
  const indicators = useMemo(() => computeAllIndicators(candles), [candles]);
  const models = useMemo(() => runAllModels(candles), [candles]);
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  const lastChangePct = prev ? ((last.close - prev.close) / prev.close) * 100 : 0;
  const insight = useMemo(
    () => ensembleInsight(models, last.close),
    [models, last.close],
  );
  const sentiment = useMemo(() => generateSentiment(symbol, lastChangePct), [symbol, lastChangePct]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold tracking-tight">{symbol}</h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 font-medium">
              AI Enhanced
            </span>
          </div>
          <div className="text-sm text-slate-400 mt-1">
            {candles.length} trading sessions · updated {new Date().toLocaleString()}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onNavigate("models")}
            className="rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 text-xs font-medium transition"
          >
            Model Arena
          </button>
          <button
            onClick={() => onNavigate("forecast")}
            className="rounded-lg bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:brightness-110 px-4 py-2 text-xs font-semibold shadow-lg shadow-indigo-500/30 transition"
          >
            Run Forecast →
          </button>
        </div>
      </div>

      <StatCards candles={candles} indicators={indicators} lastChangePct={lastChangePct} />

      <AIInsights insight={insight} sentiment={sentiment} />

      <CandlestickChart
        candles={candles}
        indicators={indicators}
        range={range}
        onRangeChange={onRangeChange}
      />

      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-slate-500">
          Technical Indicators
        </div>
        <button
          onClick={() => setShowTechnicals((v) => !v)}
          className="text-xs text-indigo-400 hover:text-indigo-300"
        >
          {showTechnicals ? "Hide" : "Show"}
        </button>
      </div>

      {showTechnicals && <TechnicalCharts candles={candles} indicators={indicators} />}
    </div>
  );
}
