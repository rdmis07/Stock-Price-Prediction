import { useState, useRef, useEffect } from "react";
import { Search, RefreshCw, Bell, Wifi, Globe } from "lucide-react";
import { POPULAR_TICKERS } from "../lib/stockData";

interface Props {
  symbol: string;
  onSymbolChange: (s: string) => void;
  onRefresh: () => void;
  refreshing: boolean;
}

export default function Header({ symbol, onSymbolChange, onRefresh, refreshing }: Props) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = POPULAR_TICKERS.filter((t) =>
    t.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <header className="h-16 shrink-0 border-b border-white/5 bg-[#0b1020]/80 backdrop-blur-xl flex items-center gap-4 px-4 md:px-6">
      <div className="relative flex-1 max-w-xl" ref={ref}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
        <input
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && filtered[0]) {
              onSymbolChange(filtered[0]);
              setQuery("");
              setOpen(false);
            }
          }}
          placeholder="Search ticker (e.g. AAPL, TSLA, RELIANCE.NS)"
          className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-4 py-2 text-sm placeholder:text-slate-500 focus:outline-none focus:border-indigo-400"
        />
        {open && filtered.length > 0 && (
          <div className="absolute z-40 mt-1 w-full rounded-lg border border-white/10 bg-[#0d1226] shadow-2xl max-h-80 overflow-y-auto">
            {filtered.map((t) => (
              <button
                key={t}
                onClick={() => {
                  onSymbolChange(t);
                  setQuery("");
                  setOpen(false);
                }}
                className="w-full text-left px-4 py-2.5 text-sm hover:bg-indigo-500/10 flex items-center justify-between"
              >
                <span className="font-mono font-semibold">{t}</span>
                <span className="text-xs text-slate-500">Stock</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="hidden md:flex items-center gap-1 rounded-lg bg-white/5 px-3 py-1.5 text-xs">
        <Globe className="h-3.5 w-3.5 text-slate-400" />
        <span className="text-slate-300 font-medium">{symbol}</span>
      </div>

      <div className="flex items-center gap-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 text-xs text-emerald-300">
        <Wifi className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Live feed</span>
      </div>

      <button
        onClick={onRefresh}
        disabled={refreshing}
        className="p-2 rounded-lg hover:bg-white/5 transition disabled:opacity-50"
      >
        <RefreshCw className={"h-4 w-4 text-slate-300 " + (refreshing ? "animate-spin" : "")} />
      </button>

      <button className="p-2 rounded-lg hover:bg-white/5 relative">
        <Bell className="h-4 w-4 text-slate-300" />
        <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-fuchsia-500 ring-2 ring-[#0b1020]" />
      </button>
    </header>
  );
}
