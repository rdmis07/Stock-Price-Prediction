import { useMemo } from "react";
import Plot from "../lib/plotly";
import { Award } from "lucide-react";
import type { ModelPrediction } from "../types";

interface Props {
  models: ModelPrediction[];
}

export default function ModelArena({ models }: Props) {
  const sorted = useMemo(() => [...models].sort((a, b) => b.metrics.r2 - a.metrics.r2), [models]);
  const best = sorted[0];

  const plotData = useMemo(
    () =>
      models.map((m) => ({
        x: ["MAE", "RMSE", "R²"],
        y: [m.metrics.mae, m.metrics.rmse, m.metrics.r2],
        name: m.modelName,
        type: "bar" as const,
        marker: { color: m.color },
      })),
    [models],
  );

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-500">Model Arena</div>
            <div className="text-lg font-semibold mt-0.5">Head-to-head evaluation on hold-out set</div>
          </div>
          {best && (
            <div className="flex items-center gap-2 rounded-lg bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 text-xs text-amber-300">
              <Award className="h-4 w-4" />
              Leader: <span className="font-bold text-amber-200">{best.modelName}</span>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wider text-slate-500 border-b border-white/5">
                <th className="text-left py-2 px-3 font-medium">Model</th>
                <th className="text-left py-2 px-3 font-medium">Type</th>
                <th className="text-right py-2 px-3 font-medium">MAE</th>
                <th className="text-right py-2 px-3 font-medium">MSE</th>
                <th className="text-right py-2 px-3 font-medium">RMSE</th>
                <th className="text-right py-2 px-3 font-medium">R²</th>
                <th className="text-right py-2 px-3 font-medium">Acc %</th>
                <th className="text-center py-2 px-3 font-medium">Signal</th>
                <th className="text-right py-2 px-3 font-medium">Next Day</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((m) => (
                <tr
                  key={m.modelName}
                  className={
                    "border-b border-white/5 hover:bg-white/[0.02] " +
                    (m.modelName === best?.modelName ? "bg-amber-500/[0.03]" : "")
                  }
                >
                  <td className="py-3 px-3 font-semibold text-slate-100 flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ backgroundColor: m.color }}
                    />
                    {m.modelName}
                  </td>
                  <td className="py-3 px-3 text-slate-400">{m.modelType}</td>
                  <td className="py-3 px-3 text-right font-mono">{m.metrics.mae.toFixed(2)}</td>
                  <td className="py-3 px-3 text-right font-mono">{m.metrics.mse.toFixed(1)}</td>
                  <td className="py-3 px-3 text-right font-mono">{m.metrics.rmse.toFixed(2)}</td>
                  <td className="py-3 px-3 text-right font-mono">
                    <span
                      className={
                        "px-1.5 py-0.5 rounded " +
                        (m.metrics.r2 > 0.9
                          ? "bg-emerald-500/15 text-emerald-300"
                          : m.metrics.r2 > 0.7
                            ? "bg-indigo-500/15 text-indigo-300"
                            : "bg-slate-500/15 text-slate-300")
                      }
                    >
                      {m.metrics.r2.toFixed(3)}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono">{m.metrics.accuracy.toFixed(1)}</td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={
                        "text-xs font-semibold px-2 py-1 rounded " +
                        (m.signal === "BUY"
                          ? "bg-emerald-500/15 text-emerald-300"
                          : m.signal === "SELL"
                            ? "bg-rose-500/15 text-rose-300"
                            : "bg-slate-500/15 text-slate-300")
                      }
                    >
                      {m.signal}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-semibold">
                    ${m.nextDay.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Comparison bar chart */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-3">Metric comparison</div>
        <Plot
          data={plotData as Plotly.Data[]}
          layout={{
            autosize: true,
            height: 320,
            barmode: "group",
            margin: { l: 50, r: 20, t: 20, b: 40 },
            paper_bgcolor: "transparent",
            plot_bgcolor: "transparent",
            font: { color: "#94a3b8", size: 11, family: "Inter, system-ui" },
            xaxis: { gridcolor: "rgba(148,163,184,0.08)" },
            yaxis: { gridcolor: "rgba(148,163,184,0.08)" },
            legend: { orientation: "h", y: 1.12 },
          }}
          config={{ displaylogo: false, responsive: true }}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>
    </div>
  );
}
