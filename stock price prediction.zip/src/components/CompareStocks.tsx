import { useMemo, useState } from "react";
import Plot from "../lib/plotly";
import { Plus, X, ArrowUpDown } from "lucide-react";
import { generateStockData, POPULAR_TICKERS, getTickerName } from "../lib/stockData";
import { computeAllIndicators, lastValid } from "../lib/indicators";
import { runAllModels } from "../lib/models";

interface Props {
  primarySymbol: string;
}

const COLORS = ["#60a5fa", "#f472b6", "#34d399", "#fbbf24", "#a78bfa", "#22d3ee"];

export default function CompareStocks({ primarySymbol }: Props) {
  const [symbols, setSymbols] = useState<string[]>([primarySymbol, "MSFT", "GOOGL"]);
  const [showAdd, setShowAdd] = useState(false);

  // Ensure primarySymbol is always first
  useMemo(() => {
    if (symbols[0] !== primarySymbol) {
      setSymbols([primarySymbol, ...symbols.filter((s) => s !== primarySymbol).slice(0, 4)]);
    }
  }, [primarySymbol]);

  const enriched = useMemo(
    () =>
      symbols.map((sym, i) => {
        const candles = generateStockData(sym, "1Y");
        const first = candles[0].close;
        const last = candles[candles.length - 1];
        const prev = candles[candles.length - 2];
        const pctReturn = ((last.close - first) / first) * 100;
        const dayChange = ((last.close - prev.close) / prev.close) * 100;
        const indicators = computeAllIndicators(candles);
        const models = runAllModels(candles);
        const rsi = lastValid(indicators.rsi);
        const vol = lastValid(indicators.volatility);
        // Max drawdown
        let peak = -Infinity;
        let maxDd = 0;
        for (const c of candles) {
          if (c.close > peak) peak = c.close;
          const dd = (c.close - peak) / peak;
          if (dd < maxDd) maxDd = dd;
        }
        // Volatility of daily returns (annualized)
        const ensemble = models.reduce((s, m) => s + m.nextDay, 0) / models.length;
        const forecastPct = ((ensemble - last.close) / last.close) * 100;
        return {
          symbol: sym,
          name: getTickerName(sym),
          candles,
          price: last.close,
          pctReturn,
          dayChange,
          rsi,
          volatility: vol,
          maxDrawdown: maxDd * 100,
          forecastPct,
          color: COLORS[i % COLORS.length],
        };
      }),
    [symbols],
  );

  function addTicker(sym: string) {
    if (symbols.includes(sym) || symbols.length >= 6) return;
    setSymbols([...symbols, sym]);
    setShowAdd(false);
  }

  function removeTicker(sym: string) {
    if (sym === primarySymbol) return;
    setSymbols(symbols.filter((s) => s !== sym));
  }

  const normalizedTraces = enriched.map((e) => {
    const base = e.candles[0].close;
    return {
      x: e.candles.map((c) => c.date),
      y: e.candles.map((c) => ((c.close - base) / base) * 100),
      type: "scatter" as const,
      mode: "lines" as const,
      name: e.symbol,
      line: { color: e.color, width: 2 },
    };
  });

  const correlationMatrix = useMemo(() => {
    const n = enriched.length;
    const returns = enriched.map((e) => {
      const out: number[] = [];
      for (let i = 1; i < e.candles.length; i++) {
        out.push(Math.log(e.candles[i].close / e.candles[i - 1].close));
      }
      return out;
    });
    const mat: number[][] = [];
    for (let i = 0; i < n; i++) {
      const row: number[] = [];
      for (let j = 0; j < n; j++) {
        row.push(pearson(returns[i], returns[j]));
      }
      mat.push(row);
    }
    return mat;
  }, [enriched]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-slate-500">Multi-Stock Analysis</div>
          <h1 className="text-2xl font-bold mt-0.5 flex items-center gap-2">
            <ArrowUpDown className="h-6 w-6 text-indigo-400" />
            Compare Stocks
          </h1>
          <div className="text-sm text-slate-400 mt-1">
            Normalized returns, correlation, and risk metrics across {symbols.length} tickers
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowAdd((v) => !v)}
            disabled={symbols.length >= 6}
            className="flex items-center gap-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 disabled:opacity-50 px-4 py-2 text-sm font-semibold transition"
          >
            <Plus className="h-4 w-4" />
            Add Ticker
          </button>
          {showAdd && (
            <div className="absolute right-0 mt-2 w-56 rounded-lg border border-white/10 bg-[#0d1226] shadow-2xl max-h-72 overflow-y-auto z-20">
              {POPULAR_TICKERS.filter((t) => !symbols.includes(t)).map((t) => (
                <button
                  key={t}
                  onClick={() => addTicker(t)}
                  className="w-full text-left px-3 py-2 text-sm hover:bg-indigo-500/10 flex items-center justify-between"
                >
                  <span className="font-mono font-semibold">{t}</span>
                  <span className="text-xs text-slate-500">{getTickerName(t)}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Ticker chips */}
      <div className="flex flex-wrap gap-2">
        {enriched.map((e) => (
          <div
            key={e.symbol}
            className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-sm"
          >
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: e.color }} />
            <span className="font-mono font-semibold">{e.symbol}</span>
            {e.symbol !== primarySymbol && (
              <button
                onClick={() => removeTicker(e.symbol)}
                className="p-0.5 rounded hover:bg-white/10"
              >
                <X className="h-3 w-3 text-slate-400" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Normalized performance */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">
          Normalized Performance (1Y, % return)
        </div>
        <Plot
          data={normalizedTraces as Plotly.Data[]}
          layout={{
            autosize: true,
            height: 380,
            margin: { l: 50, r: 20, t: 10, b: 40 },
            paper_bgcolor: "transparent",
            plot_bgcolor: "transparent",
            font: { color: "#94a3b8", size: 11, family: "Inter, system-ui" },
            xaxis: { gridcolor: "rgba(148,163,184,0.08)" },
            yaxis: { gridcolor: "rgba(148,163,184,0.08)", side: "right" as const, title: "Return %" },
            legend: { orientation: "h", y: 1.12 },
            hovermode: "x unified",
            shapes: [
              {
                type: "line",
                x0: 0,
                x1: 1,
                xref: "paper",
                y0: 0,
                y1: 0,
                line: { color: "rgba(148,163,184,0.3)", width: 1, dash: "dash" },
              },
            ],
          }}
          config={{ displaylogo: false, responsive: true }}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>

      {/* Comparison table */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5 overflow-x-auto">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-3">
          Risk & Return Metrics
        </div>
        <table className="w-full text-sm min-w-[700px]">
          <thead>
            <tr className="text-xs uppercase tracking-wider text-slate-500 border-b border-white/5">
              <th className="text-left py-2 px-3 font-medium">Ticker</th>
              <th className="text-right py-2 px-3 font-medium">Price</th>
              <th className="text-right py-2 px-3 font-medium">Day Δ</th>
              <th className="text-right py-2 px-3 font-medium">1Y Return</th>
              <th className="text-right py-2 px-3 font-medium">Max DD</th>
              <th className="text-right py-2 px-3 font-medium">Volatility</th>
              <th className="text-right py-2 px-3 font-medium">RSI</th>
              <th className="text-right py-2 px-3 font-medium">AI Forecast</th>
            </tr>
          </thead>
          <tbody>
            {enriched.map((e) => (
              <tr key={e.symbol} className="border-b border-white/5 hover:bg-white/[0.02]">
                <td className="py-3 px-3 font-semibold">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: e.color }} />
                    <div>
                      <div className="font-mono">{e.symbol}</div>
                      <div className="text-[10px] text-slate-500 font-normal">{e.name}</div>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-3 text-right font-mono">${e.price.toFixed(2)}</td>
                <td
                  className={
                    "py-3 px-3 text-right font-mono font-semibold " +
                    (e.dayChange >= 0 ? "text-emerald-400" : "text-rose-400")
                  }
                >
                  {e.dayChange >= 0 ? "+" : ""}
                  {e.dayChange.toFixed(2)}%
                </td>
                <td
                  className={
                    "py-3 px-3 text-right font-mono font-semibold " +
                    (e.pctReturn >= 0 ? "text-emerald-400" : "text-rose-400")
                  }
                >
                  {e.pctReturn >= 0 ? "+" : ""}
                  {e.pctReturn.toFixed(1)}%
                </td>
                <td className="py-3 px-3 text-right font-mono text-rose-300">
                  {e.maxDrawdown.toFixed(1)}%
                </td>
                <td className="py-3 px-3 text-right font-mono">
                  {e.volatility ? (e.volatility * 100).toFixed(1) + "%" : "—"}
                </td>
                <td className="py-3 px-3 text-right font-mono">
                  {isNaN(e.rsi) ? "—" : e.rsi.toFixed(0)}
                </td>
                <td
                  className={
                    "py-3 px-3 text-right font-mono font-semibold " +
                    (e.forecastPct >= 0 ? "text-emerald-400" : "text-rose-400")
                  }
                >
                  {e.forecastPct >= 0 ? "+" : ""}
                  {e.forecastPct.toFixed(2)}%
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Correlation heatmap */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">
          Return Correlation Matrix
        </div>
        <div className="text-xs text-slate-400 mb-3">
          Pearson correlation of daily log returns — useful for portfolio diversification analysis
        </div>
        <Plot
          data={[
            {
              z: correlationMatrix,
              x: symbols,
              y: symbols,
              type: "heatmap" as const,
              colorscale: [
                [0, "#7f1d1d"],
                [0.5, "#1e1b4b"],
                [1, "#059669"],
              ],
              zmin: -1,
              zmax: 1,
              text: correlationMatrix.map((row) => row.map((v) => v.toFixed(2))),
              texttemplate: "%{text}",
              textfont: { size: 12, color: "#e2e8f0" },
              hoverongaps: false,
            } as Plotly.Data,
          ]}
          layout={{
            autosize: true,
            height: 380,
            margin: { l: 80, r: 40, t: 20, b: 60 },
            paper_bgcolor: "transparent",
            plot_bgcolor: "transparent",
            font: { color: "#94a3b8", size: 12, family: "Inter, system-ui" },
            xaxis: { side: "bottom" as const },
          }}
          config={{ displaylogo: false, responsive: true }}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>
    </div>
  );
}

function pearson(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  let sa = 0,
    sb = 0,
    sa2 = 0,
    sb2 = 0,
    sab = 0;
  for (let i = 0; i < n; i++) {
    sa += a[i];
    sb += b[i];
    sa2 += a[i] * a[i];
    sb2 += b[i] * b[i];
    sab += a[i] * b[i];
  }
  const num = n * sab - sa * sb;
  const den = Math.sqrt((n * sa2 - sa * sa) * (n * sb2 - sb * sb));
  return den === 0 ? 0 : num / den;
}
