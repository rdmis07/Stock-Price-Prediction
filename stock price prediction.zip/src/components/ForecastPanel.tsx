import { useMemo, useState, useEffect } from "react";
import Plot from "../lib/plotly";
import { Download, FileText, History, Trash2 } from "lucide-react";
import Papa from "papaparse";
import type { ModelPrediction, StockCandle, ForecastHorizon, PredictionHistoryEntry } from "../types";
import { addHistory, loadHistory, clearHistory } from "../lib/predictions";

interface Props {
  candles: StockCandle[];
  models: ModelPrediction[];
  symbol: string;
}

export default function ForecastPanel({ candles, models, symbol }: Props) {
  const [horizon, setHorizon] = useState<ForecastHorizon>("7D");
  const [selectedModels, setSelectedModels] = useState<string[]>(
    models.slice(0, 4).map((m) => m.modelName),
  );

  const toggle = (name: string) => {
    setSelectedModels((s) =>
      s.includes(name) ? s.filter((x) => x !== name) : [...s, name],
    );
  };

  const [history, setHistory] = useState<PredictionHistoryEntry[]>(loadHistory());
  const [showHistory, setShowHistory] = useState(false);

  // Record prediction every time symbol / horizon changes
  useEffect(() => {
    if (candles.length === 0 || models.length === 0) return;
    const lastClose = candles[candles.length - 1].close;
    const ensembleNext = models.reduce((s, m) => s + m.nextDay, 0) / models.length;
    const changePct = ((ensembleNext - lastClose) / lastClose) * 100;
    const signal = changePct > 0.5 ? "BUY" : changePct < -0.5 ? "SELL" : "HOLD";
    const confidence = models.reduce((s, m) => s + m.confidence, 0) / models.length;
    const next = addHistory({
      symbol,
      horizon,
      lastClose,
      ensembleNext,
      signal,
      confidence,
      changePct,
    });
    setHistory(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, horizon, candles.length]);

  const lastDate = candles[candles.length - 1].date;
  const futureDates = useMemo(() => {
    const n = horizon === "1D" ? 1 : horizon === "7D" ? 7 : 30;
    const out: string[] = [];
    const d = new Date(lastDate);
    for (let i = 0; i < n; i++) {
      d.setDate(d.getDate() + 1);
      while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
      out.push(d.toISOString().slice(0, 10));
    }
    return out;
  }, [lastDate, horizon]);

  const historicalDates = candles.slice(-60).map((c) => c.date);
  const historicalClose = candles.slice(-60).map((c) => c.close);

  const forecastTraces = useMemo(
    () =>
      models
        .filter((m) => selectedModels.includes(m.modelName))
        .map((m) => {
          const series = horizon === "1D" ? [m.nextDay] : horizon === "7D" ? m.forecast7 : m.forecast30;
          return {
            x: [...historicalDates.slice(-1), ...futureDates],
            y: [...historicalClose.slice(-1), ...series],
            type: "scatter" as const,
            mode: "lines+markers" as const,
            name: m.modelName,
            line: { color: m.color, width: 2.5 },
            marker: { size: 5 },
          };
        }),
    [models, selectedModels, futureDates, historicalDates, historicalClose, horizon],
  );

  function exportCSV() {
    const rows: Record<string, string | number>[] = [];
    const n = horizon === "1D" ? 1 : horizon === "7D" ? 7 : 30;
    for (let i = 0; i < n; i++) {
      const row: Record<string, string | number> = { date: futureDates[i] };
      models.forEach((m) => {
        const s = horizon === "1D" ? [m.nextDay] : horizon === "7D" ? m.forecast7 : m.forecast30;
        row[m.modelName] = s[i]?.toFixed(2) ?? "";
      });
      rows.push(row);
    }
    const csv = Papa.unparse(rows);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${symbol}_forecast_${horizon}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportPDF() {
    // Open a clean printable report window and trigger print-to-PDF.
    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];
    const dayChange = prev ? ((last.close - prev.close) / prev.close) * 100 : 0;
    const w = window.open("", "_blank", "width=900,height=1200");
    if (!w) return;
    const horizonLabel = horizon === "1D" ? "Next day" : horizon === "7D" ? "7-day" : "30-day";
    const rows = models
      .map(
        (m) => `
      <tr>
        <td>${m.modelName}</td>
        <td>$${m.nextDay.toFixed(2)}</td>
        <td>${(m.confidence * 100).toFixed(0)}%</td>
        <td>${m.metrics.r2.toFixed(3)}</td>
        <td>${m.metrics.rmse.toFixed(2)}</td>
        <td>${m.signal}</td>
      </tr>`,
      )
      .join("");
    w.document.write(`<!doctype html><html><head><title>${symbol} Forecast Report</title>
      <style>
        body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;padding:40px;color:#111;max-width:800px;margin:0 auto}
        h1{font-size:28px;margin:0 0 4px}
        .sub{color:#666;font-size:13px;margin-bottom:30px}
        .stat{display:inline-block;padding:12px 18px;border:1px solid #e5e7eb;border-radius:8px;margin-right:8px;margin-bottom:8px}
        .stat .label{font-size:10px;text-transform:uppercase;color:#888;letter-spacing:1px}
        .stat .val{font-size:22px;font-weight:700;margin-top:4px}
        table{width:100%;border-collapse:collapse;margin:20px 0;font-size:13px}
        th,td{border:1px solid #e5e7eb;padding:8px 10px;text-align:left}
        th{background:#f3f4f6;font-weight:600}
        .footer{margin-top:40px;padding-top:20px;border-top:1px solid #e5e7eb;font-size:11px;color:#888}
      </style></head><body>
      <h1>${symbol} Forecast Report</h1>
      <div class="sub">Generated ${new Date().toLocaleString()} · ${horizonLabel} ensemble outlook</div>
      <div>
        <div class="stat"><div class="label">Last Close</div><div class="val">$${last.close.toFixed(2)}</div></div>
        <div class="stat"><div class="label">Day Change</div><div class="val">${dayChange >= 0 ? "+" : ""}${dayChange.toFixed(2)}%</div></div>
        <div class="stat"><div class="label">Volume</div><div class="val">${(last.volume / 1e6).toFixed(1)}M</div></div>
      </div>
      <h3 style="margin-top:30px">Model Predictions (${horizonLabel})</h3>
      <table>
        <thead><tr><th>Model</th><th>Next Price</th><th>Confidence</th><th>R²</th><th>RMSE</th><th>Signal</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <h3>Forecast Series (${horizonLabel})</h3>
      <table>
        <thead><tr><th>Date</th>${models.map((m) => `<th>${m.modelName}</th>`).join("")}</tr></thead>
        <tbody>
          ${futureDates
            .map(
              (d, i) => `<tr><td>${d}</td>${models
                .map((m) => {
                  const s = horizon === "1D" ? [m.nextDay] : horizon === "7D" ? m.forecast7 : m.forecast30;
                  return `<td>$${s[i]?.toFixed(2) ?? "—"}</td>`;
                })
                .join("")}</tr>`,
            )
            .join("")}
        </tbody>
      </table>
      <div class="footer">
        StockOracle AI · For research purposes only. Not financial advice.<br/>
        Forecasts are probabilistic estimates based on historical data and ML models.
      </div>
      <script>window.onload=()=>window.print()</script>
    </body></html>`);
    w.document.close();
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-500">Future Price Forecast</div>
            <div className="text-lg font-semibold mt-0.5">
              {horizon === "1D" ? "Next session" : horizon === "7D" ? "7-day" : "30-day"} ensemble outlook
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-lg bg-white/5 p-1">
              {(["1D", "7D", "30D"] as ForecastHorizon[]).map((h) => (
                <button
                  key={h}
                  onClick={() => setHorizon(h)}
                  className={
                    "px-3 py-1 rounded text-xs font-medium transition " +
                    (horizon === h ? "bg-indigo-500 text-white" : "text-slate-400 hover:text-white")
                  }
                >
                  {h}
                </button>
              ))}
            </div>
            <button
              onClick={exportCSV}
              className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-1.5 text-xs font-medium transition"
            >
              <Download className="h-3.5 w-3.5" />
              CSV
            </button>
            <button
              onClick={exportPDF}
              className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-1.5 text-xs font-medium transition"
            >
              <FileText className="h-3.5 w-3.5" />
              PDF
            </button>
            <button
              onClick={() => setShowHistory((v) => !v)}
              className={
                "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition " +
                (showHistory
                  ? "bg-indigo-500/20 border border-indigo-400/40 text-indigo-200"
                  : "border border-white/10 bg-white/5 hover:bg-white/10")
              }
            >
              <History className="h-3.5 w-3.5" />
              History ({history.length})
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {models.map((m) => (
            <button
              key={m.modelName}
              onClick={() => toggle(m.modelName)}
              className={
                "flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium transition " +
                (selectedModels.includes(m.modelName)
                  ? "border-white/20 bg-white/10 text-white"
                  : "border-white/5 bg-white/[0.02] text-slate-400 hover:text-white")
              }
            >
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: m.color }} />
              {m.modelName}
            </button>
          ))}
        </div>

        <Plot
          data={[
            {
              x: historicalDates,
              y: historicalClose,
              type: "scatter",
              mode: "lines",
              name: "Historical",
              line: { color: "#cbd5e1", width: 2 },
            } as Plotly.Data,
            ...(forecastTraces as Plotly.Data[]),
          ]}
          layout={{
            autosize: true,
            height: 420,
            margin: { l: 50, r: 20, t: 10, b: 40 },
            paper_bgcolor: "transparent",
            plot_bgcolor: "transparent",
            font: { color: "#94a3b8", size: 11, family: "Inter, system-ui" },
            xaxis: { gridcolor: "rgba(148,163,184,0.08)" },
            yaxis: { gridcolor: "rgba(148,163,184,0.08)", side: "right" as const },
            legend: { orientation: "h", y: 1.12 },
            hovermode: "x unified",
            shapes: [
              {
                type: "line",
                x0: lastDate,
                x1: lastDate,
                y0: 0,
                y1: 1,
                yref: "paper",
                line: { color: "rgba(148,163,184,0.4)", width: 1, dash: "dash" },
              },
            ],
          }}
          config={{ displaylogo: false, responsive: true }}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>

      {/* Per-model forecast cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {models.map((m) => {
          const last = candles[candles.length - 1].close;
          const delta = ((m.nextDay - last) / last) * 100;
          return (
            <div
              key={m.modelName}
              className="rounded-2xl border border-white/5 bg-white/[0.02] p-4"
            >
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: m.color }} />
                <div className="text-sm font-semibold">{m.modelName}</div>
                <span className="ml-auto text-[10px] uppercase text-slate-500">{m.modelType}</span>
              </div>
              <div className="mt-3 text-2xl font-bold">${m.nextDay.toFixed(2)}</div>
              <div
                className={
                  "text-xs font-semibold " + (delta >= 0 ? "text-emerald-400" : "text-rose-400")
                }
              >
                {delta >= 0 ? "+" : ""}
                {delta.toFixed(2)}% vs last close
              </div>
              <div className="mt-3 h-1 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full"
                  style={{
                    width: m.confidence * 100 + "%",
                    backgroundColor: m.color,
                  }}
                />
              </div>
              <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500">
                <span>Confidence</span>
                <span className="text-slate-300 font-semibold">
                  {(m.confidence * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Prediction history panel */}
      {showHistory && (
        <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-500">Prediction History</div>
              <div className="text-lg font-semibold mt-0.5">Your recent forecast calls</div>
            </div>
            <button
              onClick={() => {
                clearHistory();
                setHistory([]);
              }}
              disabled={history.length === 0}
              className="flex items-center gap-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 px-3 py-1.5 text-xs font-medium transition disabled:opacity-40"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear
            </button>
          </div>
          {history.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              No forecasts yet. Switch horizons or tickers to log predictions.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs uppercase tracking-wider text-slate-500 border-b border-white/5">
                    <th className="text-left py-2 px-3 font-medium">Time</th>
                    <th className="text-left py-2 px-3 font-medium">Symbol</th>
                    <th className="text-center py-2 px-3 font-medium">Horizon</th>
                    <th className="text-right py-2 px-3 font-medium">Last Close</th>
                    <th className="text-right py-2 px-3 font-medium">Forecast</th>
                    <th className="text-right py-2 px-3 font-medium">Δ %</th>
                    <th className="text-center py-2 px-3 font-medium">Signal</th>
                    <th className="text-right py-2 px-3 font-medium">Conf.</th>
                  </tr>
                </thead>
                <tbody>
                  {history.slice(0, 50).map((h) => (
                    <tr key={h.id} className="border-b border-white/5 hover:bg-white/[0.02]">
                      <td className="py-2.5 px-3 text-xs text-slate-400">
                        {new Date(h.timestamp).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold">{h.symbol}</td>
                      <td className="py-2.5 px-3 text-center text-xs">{h.horizon}</td>
                      <td className="py-2.5 px-3 text-right font-mono">${h.lastClose.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-right font-mono">${h.ensembleNext.toFixed(2)}</td>
                      <td
                        className={
                          "py-2.5 px-3 text-right font-mono text-xs font-semibold " +
                          (h.changePct >= 0 ? "text-emerald-400" : "text-rose-400")
                        }
                      >
                        {h.changePct >= 0 ? "+" : ""}
                        {h.changePct.toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={
                            "text-xs font-semibold px-2 py-0.5 rounded " +
                            (h.signal === "BUY"
                              ? "bg-emerald-500/15 text-emerald-300"
                              : h.signal === "SELL"
                                ? "bg-rose-500/15 text-rose-300"
                                : "bg-slate-500/15 text-slate-300")
                          }
                        >
                          {h.signal}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-xs text-slate-300">
                        {(h.confidence * 100).toFixed(0)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
