import { TrendingUp, TrendingDown, Activity, BarChart3, Zap, Brain } from "lucide-react";
import type { StockCandle, TechnicalIndicators } from "../types";
import { lastValid } from "../lib/indicators";

interface Props {
  candles: StockCandle[];
  indicators: TechnicalIndicators;
  lastChangePct: number;
}

export default function StatCards({ candles, indicators, lastChangePct }: Props) {
  const last = candles[candles.length - 1];
  const rsiVal = lastValid(indicators.rsi);
  const volVal = lastValid(indicators.volatility);
  const momVal = lastValid(indicators.momentum);
  const high52 = Math.max(...candles.slice(-252).map((c) => c.high));
  const low52 = Math.min(...candles.slice(-252).map((c) => c.low));

  const cards = [
    {
      icon: lastChangePct >= 0 ? TrendingUp : TrendingDown,
      color: lastChangePct >= 0 ? "text-emerald-400 bg-emerald-500/10" : "text-rose-400 bg-rose-500/10",
      label: "Day Change",
      value: (lastChangePct >= 0 ? "+" : "") + lastChangePct.toFixed(2) + "%",
      sub: "vs previous close",
    },
    {
      icon: Activity,
      color: "text-indigo-400 bg-indigo-500/10",
      label: "RSI (14)",
      value: isNaN(rsiVal) ? "—" : rsiVal.toFixed(1),
      sub:
        rsiVal > 70 ? "Overbought" : rsiVal < 30 ? "Oversold" : rsiVal > 50 ? "Bullish zone" : "Neutral",
    },
    {
      icon: BarChart3,
      color: "text-amber-400 bg-amber-500/10",
      label: "Volume",
      value: formatLargeNumber(last.volume),
      sub: "last session",
    },
    {
      icon: Zap,
      color: "text-rose-400 bg-rose-500/10",
      label: "Volatility",
      value: isNaN(volVal) ? "—" : (volVal * 100).toFixed(1) + "%",
      sub: "annualized (20d)",
    },
    {
      icon: TrendingUp,
      color: "text-emerald-400 bg-emerald-500/10",
      label: "Momentum (10d)",
      value: isNaN(momVal) ? "—" : (momVal >= 0 ? "+" : "") + momVal.toFixed(2) + "%",
      sub: "rate of change",
    },
    {
      icon: Brain,
      color: "text-violet-400 bg-violet-500/10",
      label: "52-Week Range",
      value: `$${low52.toFixed(0)} – $${high52.toFixed(0)}`,
      sub: "low → high",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((c) => (
        <div
          key={c.label}
          className="rounded-2xl border border-white/5 bg-white/[0.02] p-4 hover:border-white/10 transition"
        >
          <div className={"h-8 w-8 rounded-lg flex items-center justify-center " + c.color}>
            <c.icon className="h-4 w-4" />
          </div>
          <div className="mt-3 text-[11px] uppercase tracking-wider text-slate-500">{c.label}</div>
          <div className="text-lg font-bold text-slate-100 mt-0.5 leading-tight">{c.value}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">{c.sub}</div>
        </div>
      ))}
    </div>
  );
}

function formatLargeNumber(n: number): string {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(2) + "K";
  return n.toString();
}
