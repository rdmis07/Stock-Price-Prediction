import Plot from "../lib/plotly";
import type { StockCandle, TechnicalIndicators } from "../types";

interface Props {
  candles: StockCandle[];
  indicators: TechnicalIndicators;
}

export default function TechnicalCharts({ candles, indicators }: Props) {
  const dates = candles.map((c) => c.date);
  const plotlyConfig = { displaylogo: false, responsive: true } as const;
  const baseLayout: Partial<Plotly.Layout> = {
    autosize: true,
    height: 180,
    margin: { l: 40, r: 15, t: 30, b: 30 },
    paper_bgcolor: "transparent",
    plot_bgcolor: "transparent",
    font: { color: "#94a3b8", size: 10, family: "Inter, system-ui" },
    xaxis: { gridcolor: "rgba(148,163,184,0.08)", showgrid: true },
    yaxis: { gridcolor: "rgba(148,163,184,0.08)", side: "right" as const },
    showlegend: false,
    hovermode: "x unified",
  };

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {/* RSI */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-4">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">RSI (14)</div>
        <Plot
          data={[
            {
              x: dates,
              y: indicators.rsi,
              type: "scatter",
              mode: "lines",
              line: { color: "#a78bfa", width: 1.8 },
              fill: "tozeroy",
              fillcolor: "rgba(167,139,250,0.1)",
            } as Plotly.Data,
            {
              x: [dates[0], dates[dates.length - 1]],
              y: [70, 70],
              type: "scatter",
              mode: "lines",
              line: { color: "#f43f5e", width: 1, dash: "dash" },
              showlegend: false,
            } as Plotly.Data,
            {
              x: [dates[0], dates[dates.length - 1]],
              y: [30, 30],
              type: "scatter",
              mode: "lines",
              line: { color: "#10b981", width: 1, dash: "dash" },
              showlegend: false,
            } as Plotly.Data,
          ]}
          layout={{
            ...baseLayout,
            title: { text: "Relative Strength Index", font: { size: 12, color: "#cbd5e1" } },
            yaxis: { gridcolor: "rgba(148,163,184,0.08)", side: "right" as const, range: [0, 100] },
          }}
          config={plotlyConfig}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>

      {/* MACD */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-4">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">MACD (12, 26, 9)</div>
        <Plot
          data={[
            {
              x: dates,
              y: indicators.macd.histogram,
              type: "bar",
              marker: {
                color: indicators.macd.histogram.map((h) =>
                  isNaN(h) ? "transparent" : h >= 0 ? "rgba(16,185,129,0.6)" : "rgba(244,63,94,0.6)",
                ),
              },
            } as Plotly.Data,
            {
              x: dates,
              y: indicators.macd.macd,
              type: "scatter",
              mode: "lines",
              name: "MACD",
              line: { color: "#60a5fa", width: 1.5 },
            } as Plotly.Data,
            {
              x: dates,
              y: indicators.macd.signal,
              type: "scatter",
              mode: "lines",
              name: "Signal",
              line: { color: "#fbbf24", width: 1.5 },
            } as Plotly.Data,
          ]}
          layout={{
            ...baseLayout,
            title: { text: "Moving Avg Convergence Divergence", font: { size: 12, color: "#cbd5e1" } },
          }}
          config={plotlyConfig}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>

      {/* Volume + Momentum */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-4">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">Volume</div>
        <Plot
          data={[
            {
              x: dates,
              y: candles.map((c) => c.volume),
              type: "bar",
              marker: { color: "rgba(99,102,241,0.5)" },
            } as Plotly.Data,
          ]}
          layout={{
            ...baseLayout,
            title: { text: "Trading Volume", font: { size: 12, color: "#cbd5e1" } },
          }}
          config={plotlyConfig}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>

      {/* Volatility */}
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-4">
        <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">Volatility (annualized)</div>
        <Plot
          data={[
            {
              x: dates,
              y: indicators.volatility.map((v) => (isNaN(v) ? null : v * 100)),
              type: "scatter",
              mode: "lines",
              line: { color: "#fb7185", width: 1.8 },
              fill: "tozeroy",
              fillcolor: "rgba(251,113,133,0.1)",
            } as Plotly.Data,
          ]}
          layout={{
            ...baseLayout,
            title: { text: "Rolling Volatility %", font: { size: 12, color: "#cbd5e1" } },
          }}
          config={plotlyConfig}
          useResizeHandler
          style={{ width: "100%" }}
        />
      </div>
    </div>
  );
}
