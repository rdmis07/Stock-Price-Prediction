import { useMemo } from "react";
import { Plus, TrendingUp, TrendingDown, Trash2 } from "lucide-react";
import { generateStockData, POPULAR_TICKERS } from "../lib/stockData";
import type { PortfolioItem } from "../types";

interface Props {
  portfolio: PortfolioItem[];
  setPortfolio: (p: PortfolioItem[]) => void;
}

export default function Portfolio({ portfolio, setPortfolio }: Props) {
  // Refresh current prices from the deterministic generator
  const enriched = useMemo(() => {
    return portfolio.map((p) => {
      const data = generateStockData(p.symbol, "1M");
      const current = data[data.length - 1].close;
      const prev = data[data.length - 2]?.close ?? current;
      const change = ((current - prev) / prev) * 100;
      const value = current * p.shares;
      return { ...p, currentPrice: current, change, value };
    });
  }, [portfolio]);

  const totals = useMemo(() => {
    const value = enriched.reduce((s, p) => s + p.value, 0);
    const cost = enriched.reduce((s, p) => s + p.avgPrice * p.shares, 0);
    const pnl = value - cost;
    const pnlPct = cost === 0 ? 0 : (pnl / cost) * 100;
    return { value, cost, pnl, pnlPct };
  }, [enriched]);

  function addRandom() {
    const pool = POPULAR_TICKERS.filter((t) => !portfolio.some((p) => p.symbol === t));
    if (pool.length === 0) return;
    const symbol = pool[Math.floor(Math.random() * pool.length)];
    const data = generateStockData(symbol, "1M");
    const price = data[data.length - 1].close;
    const shares = Math.floor(Math.random() * 40) + 5;
    const item: PortfolioItem = {
      symbol,
      name: symbol,
      shares,
      avgPrice: price * (0.85 + Math.random() * 0.25),
      currentPrice: price,
      change: 0,
      value: price * shares,
    };
    setPortfolio([...portfolio, item]);
  }

  function remove(sym: string) {
    setPortfolio(portfolio.filter((p) => p.symbol !== sym));
  }

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Portfolio Value", value: "$" + totals.value.toFixed(2), color: "text-white" },
          { label: "Total Cost", value: "$" + totals.cost.toFixed(2), color: "text-slate-300" },
          {
            label: "Unrealized P&L",
            value: (totals.pnl >= 0 ? "+$" : "-$") + Math.abs(totals.pnl).toFixed(2),
            color: totals.pnl >= 0 ? "text-emerald-400" : "text-rose-400",
          },
          {
            label: "Return",
            value: (totals.pnlPct >= 0 ? "+" : "") + totals.pnlPct.toFixed(2) + "%",
            color: totals.pnlPct >= 0 ? "text-emerald-400" : "text-rose-400",
          },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-white/5 bg-white/[0.02] p-4">
            <div className="text-xs uppercase tracking-wider text-slate-500">{s.label}</div>
            <div className={"mt-1.5 text-2xl font-bold " + s.color}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-500">Holdings</div>
            <div className="text-lg font-semibold mt-0.5">Track your positions</div>
          </div>
          <button
            onClick={addRandom}
            className="flex items-center gap-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 px-3 py-1.5 text-xs font-semibold transition"
          >
            <Plus className="h-3.5 w-3.5" />
            Add Position
          </button>
        </div>

        {portfolio.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-sm">
            No positions yet. Click <span className="text-slate-300">Add Position</span> to seed a random holding.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs uppercase tracking-wider text-slate-500 border-b border-white/5">
                  <th className="text-left py-2 px-3 font-medium">Symbol</th>
                  <th className="text-right py-2 px-3 font-medium">Shares</th>
                  <th className="text-right py-2 px-3 font-medium">Avg Cost</th>
                  <th className="text-right py-2 px-3 font-medium">Current</th>
                  <th className="text-right py-2 px-3 font-medium">Change</th>
                  <th className="text-right py-2 px-3 font-medium">Value</th>
                  <th className="py-2 px-3" />
                </tr>
              </thead>
              <tbody>
                {enriched.map((p) => {
                  const pnl = (p.currentPrice - p.avgPrice) * p.shares;
                  return (
                    <tr key={p.symbol} className="border-b border-white/5 hover:bg-white/[0.02]">
                      <td className="py-3 px-3 font-mono font-semibold">{p.symbol}</td>
                      <td className="py-3 px-3 text-right font-mono">{p.shares}</td>
                      <td className="py-3 px-3 text-right font-mono">${p.avgPrice.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right font-mono">${p.currentPrice.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right">
                        <div
                          className={
                            "inline-flex items-center gap-1 text-xs font-semibold " +
                            (p.change >= 0 ? "text-emerald-400" : "text-rose-400")
                          }
                        >
                          {p.change >= 0 ? (
                            <TrendingUp className="h-3 w-3" />
                          ) : (
                            <TrendingDown className="h-3 w-3" />
                          )}
                          {p.change >= 0 ? "+" : ""}
                          {p.change.toFixed(2)}%
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {pnl >= 0 ? "+$" : "-$"}
                          {Math.abs(pnl).toFixed(2)}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold">${p.value.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => remove(p.symbol)}
                          className="p-1.5 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
