import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, X, Send, Sparkles, Bot, User } from "lucide-react";
import type { ModelPrediction, StockCandle } from "../types";
import { ensembleInsight } from "../lib/models";
import { lastValid } from "../lib/indicators";
import type { TechnicalIndicators } from "../types";

interface Props {
  symbol: string;
  candles: StockCandle[];
  models: ModelPrediction[];
  indicators: TechnicalIndicators | null;
}

interface ChatMessage {
  role: "user" | "assistant";
  text: string;
}

const SUGGESTIONS = [
  "Should I buy this stock?",
  "What do the models predict?",
  "Explain the RSI signal",
  "Which model is best?",
  "What's the 7-day forecast?",
];

export default function Chatbot({ symbol, candles, models, indicators }: Props) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      text: `Hi, I'm the StockOracle AI assistant. Ask me anything about ${symbol}.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, typing]);

  function answer(question: string): string {
    const q = question.toLowerCase();
    if (candles.length === 0 || models.length === 0) {
      return "I'm still loading market data — give me a second and ask again.";
    }
    const last = candles[candles.length - 1];
    const insight = ensembleInsight(models, last.close);

    // Forecast questions
    if (/(forecast|predict|future|next|tomorrow|7.?day|30.?day)/.test(q)) {
      return `${symbol} closed at $${last.close.toFixed(2)}. The AI ensemble forecasts $${insight.ensembleNext.toFixed(
        2,
      )} next session (${insight.ensembleNext > last.close ? "+" : ""}${(
        ((insight.ensembleNext - last.close) / last.close) *
        100
      ).toFixed(2)}%) with ${insight.confidence.toFixed(0)}% confidence. The 7-model consensus signal is **${insight.signal}**.`;
    }

    // Buy/Sell/Hold
    if (/(buy|sell|hold|recommend|should i)/.test(q)) {
      return `My ensemble signal is **${insight.signal}** (${insight.trend.toLowerCase()} trend, strength ${insight.strength.toFixed(
        0,
      )}/100). Risk level: ${insight.risk}. Key reasons: ${insight.reasons
        .slice(0, 3)
        .join("; ")}. Remember — this is probabilistic, not a guarantee.`;
    }

    // RSI
    if (/rsi/.test(q)) {
      const rsiVal = indicators ? lastValid(indicators.rsi) : NaN;
      if (isNaN(rsiVal)) return "RSI is still computing (need ≥14 bars of data).";
      const zone = rsiVal > 70 ? "overbought (>70) — reversal risk" : rsiVal < 30 ? "oversold (<30) — bounce likely" : rsiVal > 50 ? "bullish territory" : "bearish territory";
      return `Current RSI(14) is **${rsiVal.toFixed(1)}** — ${zone}. RSI measures the velocity of price changes on a 0-100 scale.`;
    }

    // MACD
    if (/macd/.test(q)) {
      if (!indicators) return "MACD not computed yet.";
      const m = lastValid(indicators.macd.macd);
      const s = lastValid(indicators.macd.signal);
      const cross = m > s ? "bullish" : "bearish";
      return `MACD line is ${m.toFixed(3)} and the signal is ${s.toFixed(3)} — a **${cross}** configuration. When MACD crosses above the signal, momentum is accelerating to the upside.`;
    }

    // Model comparison / best model
    if (/(best|model|compare|which|accurate)/.test(q)) {
      const sorted = [...models].sort((a, b) => b.metrics.r2 - a.metrics.r2);
      const top = sorted[0];
      return `**${top.modelName}** leads with R²=${top.metrics.r2.toFixed(3)} and RMSE=${top.metrics.rmse.toFixed(
        2,
      )}. Full leaderboard: ${sorted
        .slice(0, 4)
        .map((m) => `${m.modelName} (R²=${m.metrics.r2.toFixed(3)})`)
        .join(", ")}.`;
    }

    // Price / current
    if (/(price|current|today|last)/.test(q)) {
      const prev = candles[candles.length - 2];
      const change = ((last.close - prev.close) / prev.close) * 100;
      return `${symbol} last traded at **$${last.close.toFixed(2)}** (${change >= 0 ? "+" : ""}${change.toFixed(
        2,
      )}% vs previous session). Today's range: $${last.low.toFixed(2)} – $${last.high.toFixed(
        2,
      )}.`;
    }

    // Volatility
    if (/(volatil|risk|variance)/.test(q)) {
      const v = indicators ? lastValid(indicators.volatility) : NaN;
      if (isNaN(v)) return "Volatility not available yet.";
      return `Annualized rolling volatility (20d) is **${(v * 100).toFixed(1)}%** — ${
        v > 0.4 ? "elevated, expect wide swings" : v > 0.25 ? "moderate" : "calm market conditions"
      }.`;
    }

    // Help
    if (/(help|what|can you)/.test(q)) {
      return `I can answer questions about: price action, forecasts, RSI, MACD, volatility, model accuracy, and buy/sell signals. Try one of the suggestions below.`;
    }

    // Default fallback — context-aware summary
    return `Here's a snapshot of ${symbol}: last close $${last.close.toFixed(2)}, ensemble forecast ${insight.signal} with ${(
      insight.confidence
    ).toFixed(0)}% confidence. RSI is ${indicators ? lastValid(indicators.rsi).toFixed(1) : "—"}, and ${
      insight.votes.BUY
    } of ${models.length} models signal BUY. Want me to dig into any of these?`;
  }

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed) return;
    setMessages((m) => [...m, { role: "user", text: trimmed }]);
    setInput("");
    setTyping(true);
    await new Promise((r) => setTimeout(r, 600 + Math.random() * 500));
    setMessages((m) => [...m, { role: "assistant", text: answer(trimmed) }]);
    setTyping(false);
  }

  return (
    <>
      {/* Floating button */}
      <AnimatePresence>
        {!open && (
          <motion.button
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            whileHover={{ scale: 1.05 }}
            onClick={() => setOpen(true)}
            className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-2xl shadow-indigo-500/50 flex items-center justify-center z-40"
          >
            <MessageSquare className="h-6 w-6 text-white" />
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-emerald-400 ring-2 ring-[#0a0e1a] flex items-center justify-center text-[9px] font-bold text-[#0a0e1a]">
              AI
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 w-[min(92vw,400px)] h-[min(85vh,580px)] rounded-2xl border border-white/10 bg-[#0b1020]/95 backdrop-blur-xl shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/5 bg-gradient-to-r from-indigo-500/10 to-fuchsia-500/10">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center shadow-lg">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">StockOracle AI Assistant</div>
                  <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Online · {symbol}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/5"
              >
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={"flex gap-2 " + (m.role === "user" ? "justify-end" : "justify-start")}
                >
                  {m.role === "assistant" && (
                    <div className="h-7 w-7 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center shrink-0">
                      <Bot className="h-3.5 w-3.5 text-white" />
                    </div>
                  )}
                  <div
                    className={
                      "max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed " +
                      (m.role === "user"
                        ? "bg-indigo-500 text-white rounded-br-sm"
                        : "bg-white/5 border border-white/5 text-slate-200 rounded-bl-sm")
                    }
                  >
                    {m.text.split("**").map((part, idx) =>
                      idx % 2 === 1 ? (
                        <strong key={idx} className="text-white font-semibold">
                          {part}
                        </strong>
                      ) : (
                        <span key={idx}>{part}</span>
                      ),
                    )}
                  </div>
                  {m.role === "user" && (
                    <div className="h-7 w-7 rounded-full bg-slate-700 flex items-center justify-center shrink-0">
                      <User className="h-3.5 w-3.5 text-white" />
                    </div>
                  )}
                </motion.div>
              ))}
              {typing && (
                <div className="flex gap-2">
                  <div className="h-7 w-7 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center">
                    <Bot className="h-3.5 w-3.5 text-white" />
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-2xl rounded-bl-sm px-3.5 py-2.5 flex gap-1">
                    <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce" />
                    <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce [animation-delay:120ms]" />
                    <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce [animation-delay:240ms]" />
                  </div>
                </div>
              )}
            </div>

            {/* Suggestions */}
            <div className="px-4 pb-2 flex gap-2 overflow-x-auto scrollbar-none">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="shrink-0 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-1 text-xs text-slate-300 transition"
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="p-3 border-t border-white/5 flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Ask about ${symbol}…`}
                className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:border-indigo-400 placeholder:text-slate-500"
              />
              <button
                type="submit"
                disabled={!input.trim() || typing}
                className="h-9 w-9 rounded-lg bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center disabled:opacity-40 hover:brightness-110 transition"
              >
                <Send className="h-4 w-4 text-white" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
