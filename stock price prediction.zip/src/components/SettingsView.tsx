import { useState } from "react";
import { Moon, Sun, Mail, Bell, Globe } from "lucide-react";

interface Props {
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  email: string;
}

export default function SettingsView({ darkMode, setDarkMode, email }: Props) {
  const [alerts, setAlerts] = useState({ email: true, push: true, news: false });
  const [region, setRegion] = useState("US");

  return (
    <div className="max-w-3xl space-y-4">
      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-xs uppercase tracking-wider text-slate-500">Account</div>
        <div className="text-lg font-semibold mt-0.5 mb-4">Profile settings</div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Email" icon={<Mail className="h-4 w-4" />} value={email} disabled />
          <Field label="Region" icon={<Globe className="h-4 w-4" />}>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:border-indigo-400"
            >
              <option value="US">US (NASDAQ / NYSE)</option>
              <option value="IN">India (NSE / BSE)</option>
              <option value="UK">UK (LSE)</option>
              <option value="EU">Europe</option>
            </select>
          </Field>
        </div>
      </div>

      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5">
        <div className="text-xs uppercase tracking-wider text-slate-500">Preferences</div>
        <div className="text-lg font-semibold mt-0.5 mb-4">Appearance & notifications</div>

        <div className="space-y-3">
          <Toggle
            label="Dark mode"
            desc="Use the deep-space theme (always recommended)"
            icon={darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            checked={darkMode}
            onChange={setDarkMode}
          />
          <Toggle
            label="Email alerts"
            desc="Daily forecast summary to your inbox"
            icon={<Mail className="h-4 w-4" />}
            checked={alerts.email}
            onChange={(v) => setAlerts({ ...alerts, email: v })}
          />
          <Toggle
            label="Push notifications"
            desc="Real-time alerts on large moves"
            icon={<Bell className="h-4 w-4" />}
            checked={alerts.push}
            onChange={(v) => setAlerts({ ...alerts, push: v })}
          />
          <Toggle
            label="News sentiment digest"
            desc="Daily FinBERT headline digest"
            icon={<Globe className="h-4 w-4" />}
            checked={alerts.news}
            onChange={(v) => setAlerts({ ...alerts, news: v })}
          />
        </div>
      </div>

      <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-5 text-xs text-slate-400">
        <div className="text-slate-300 font-semibold mb-1">Disclaimer</div>
        StockOracle AI is an educational research tool. Forecasts are probabilistic estimates and
        do not constitute financial advice. Always perform independent due diligence.
      </div>
    </div>
  );
}

function Field({
  label,
  icon,
  value,
  disabled,
  children,
}: {
  label: string;
  icon?: React.ReactNode;
  value?: string;
  disabled?: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-xs font-medium text-slate-400 mb-1.5 block">{label}</label>
      {children ? (
        children
      ) : (
        <div className="relative">
          {icon && (
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">{icon}</span>
          )}
          <input
            value={value}
            disabled={disabled}
            className={
              "w-full rounded-lg border border-white/10 bg-white/5 " +
              (icon ? "pl-10" : "pl-3") +
              " pr-3 py-2 text-sm disabled:opacity-60"
            }
          />
        </div>
      )}
    </div>
  );
}

function Toggle({
  label,
  desc,
  icon,
  checked,
  onChange,
}: {
  label: string;
  desc: string;
  icon: React.ReactNode;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-white/5 bg-white/[0.02] p-3">
      <div className="h-9 w-9 rounded-lg bg-white/5 flex items-center justify-center text-slate-400">
        {icon}
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium text-slate-200">{label}</div>
        <div className="text-xs text-slate-500">{desc}</div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={
          "relative h-6 w-11 rounded-full transition " +
          (checked ? "bg-indigo-500" : "bg-white/10")
        }
      >
        <span
          className={
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition " +
            (checked ? "left-5" : "left-0.5")
          }
        />
      </button>
    </div>
  );
}
