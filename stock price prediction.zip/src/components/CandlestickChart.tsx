import { useMemo } from "react";
import Plot from "../lib/plotly";
import type { StockCandle, TechnicalIndicators, TimeRange } from "../types";

interface Props {
  candles: StockCandle[];
  indicators: TechnicalIndicators;
  range: TimeRange;
  onRangeChange: (r: TimeRange) => void;
}

const RANGES: TimeRange[] = ["1M", "3M", "6M", "1Y", "2Y", "5Y"];

export default function CandlestickChart({ candles, indicators, range, onRangeChange }: Props) {
  const plotData = useMemo(() => {
    const dates = candles.map((c) => c.date);
    const candlestick = {
      x: dates,
      open: candles.map((c) => c.open),
      high: candles.map((c) => c.high),
      low: candles.map((c) => c.low),
      close: candles.map((c) => c.close),
      type: "candlestick" as const,
      name: "Price",
      increasing: { line: { color: "#10b981" } },
      decreasing: { line: { color: "#f43f5e" } },
    };
    const bbFill = {
      x: [...dates, ...dates.slice().reverse()],
      y: [...indicators.bollinger.upper, ...indicators.bollinger.lower.slice().reverse()],
      fill: "toself",
      fillcolor: "rgba(99,102,241,0.06)",
      line: { color: "transparent" },
      showlegend: false,
      type: "scatter" as const,
      hoverinfo: "skip" as const,
    };
    const sma20 = {
      x: dates,
      y: indicators.sma20,
      type: "scatter" as const,
      mode: "lines" as const,
      name: "SMA 20",
      line: { color: "#60a5fa", width: 1.5 },
    };
    const sma50 = {
      x: dates,
      y: indicators.sma50,
      type: "scatter" as const,
      mode: "lines" as const,
      name: "SMA 50",
      line: { color: "#fbbf24", width: 1.5 },
    };
    const bbUpper = {
      x: dates,
      y: indicators.bollinger.upper,
      type: "scatter" as const,
      mode: "lines" as const,
      name: "BB Upper",
      line: { color: "rgba(139,92,246,0.5)", width: 1, dash: "dot" as const },
    };
    const bbLower = {
      x: dates,
      y: indicators.bollinger.lower,
      type: "scatter" as const,
      mode: "lines" as const,
      name: "BB Lower",
      line: { color: "rgba(139,92,246,0.5)", width: 1, dash: "dot" as const },
    };
    return [bbFill, candlestick, sma20, sma50, bbUpper, bbLower];
  }, [candles, indicators]);

  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  const change = last && prev ? last.close - prev.close : 0;
  const changePct = last && prev ? (change / prev.close) * 100 : 0;

  return (
    <div className="rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.03] to-transparent p-5">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <div className="text-xs uppercase tracking-wider text-slate-500">Price Action</div>
          <div className="text-2xl font-bold mt-0.5">
            {last ? `$${last.close.toFixed(2)}` : "—"}
            {last && (
              <span
                className={
                  "ml-3 text-sm font-medium " + (change >= 0 ? "text-emerald-400" : "text-rose-400")
                }
              >
                {change >= 0 ? "+" : ""}
                {change.toFixed(2)} ({changePct.toFixed(2)}%)
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 rounded-lg bg-white/5 p-1">
          {RANGES.map((r) => (
            <button
              key={r}
              onClick={() => onRangeChange(r)}
              className={
                "px-3 py-1 rounded text-xs font-medium transition " +
                (range === r
                  ? "bg-indigo-500 text-white shadow"
                  : "text-slate-400 hover:text-white")
              }
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <Plot
        data={plotData as unknown as Plotly.Data[]}
        layout={{
          autosize: true,
          height: 440,
          margin: { l: 50, r: 20, t: 10, b: 40 },
          paper_bgcolor: "transparent",
          plot_bgcolor: "transparent",
          font: { color: "#94a3b8", size: 11, family: "Inter, system-ui" },
          xaxis: {
            gridcolor: "rgba(148,163,184,0.08)",
            linecolor: "rgba(148,163,184,0.1)",
            rangeslider: { visible: false },
          },
          yaxis: {
            gridcolor: "rgba(148,163,184,0.08)",
            linecolor: "rgba(148,163,184,0.1)",
            side: "right",
          },
          legend: {
            orientation: "h",
            y: 1.12,
            x: 0,
            font: { size: 11 },
          },
          hovermode: "x unified",
        }}
        config={{ displaylogo: false, responsive: true }}
        useResizeHandler
        style={{ width: "100%" }}
      />
    </div>
  );
}
