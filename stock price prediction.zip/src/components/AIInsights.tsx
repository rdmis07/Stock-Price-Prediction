import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ShieldCheck,
  AlertTriangle,
  Brain,
  Newspaper,
} from "lucide-react";
import type { AIInsight, Sentiment } from "../types";

interface Props {
  insight: AIInsight;
  sentiment: Sentiment;
}

export default function AIInsights({ insight, sentiment }: Props) {
  const signalColor: Record<string, string> = {
    "Strong Buy": "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
    Buy: "text-emerald-300 bg-emerald-500/10 border-emerald-500/20",
    Hold: "text-amber-300 bg-amber-500/10 border-amber-500/20",
    Sell: "text-rose-300 bg-rose-500/10 border-rose-500/20",
    "Strong Sell": "text-rose-400 bg-rose-500/10 border-rose-500/30",
  };
  const TrendIcon =
    insight.trend === "Upward" ? TrendingUp : insight.trend === "Downward" ? TrendingDown : Minus;
  const trendColor =
    insight.trend === "Upward" ? "text-emerald-400" : insight.trend === "Downward" ? "text-rose-400" : "text-slate-400";

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      {/* AI Recommendation */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-white/5 bg-gradient-to-br from-indigo-500/10 via-violet-500/5 to-fuchsia-500/10 p-5 relative overflow-hidden"
      >
        <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-indigo-300 font-semibold">
            <Brain className="h-4 w-4" />
            AI Consensus Signal
          </div>

          <div className="mt-4 flex items-center gap-4">
            <div
              className={
                "text-3xl font-bold px-4 py-2 rounded-xl border " + signalColor[insight.signal]
              }
            >
              {insight.signal}
            </div>
            <div className={"flex items-center gap-2 " + trendColor}>
              <TrendIcon className="h-6 w-6" />
              <div>
                <div className="text-sm font-semibold">{insight.trend} Trend</div>
                <div className="text-xs text-slate-400">Strength {insight.strength.toFixed(0)}/100</div>
              </div>
            </div>
          </div>

          <div className="mt-5">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Ensemble confidence</span>
              <span className="text-slate-200 font-medium">{insight.confidence.toFixed(0)}%</span>
            </div>
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: insight.confidence + "%" }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500"
              />
            </div>
          </div>

          <ul className="mt-4 space-y-1.5">
            {insight.reasons.map((r, i) => (
              <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-indigo-400 shrink-0" />
                {r}
              </li>
            ))}
          </ul>

          <div className="mt-4 flex items-center gap-2 text-xs">
            {insight.risk === "Low" ? (
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-amber-400" />
            )}
            <span className="text-slate-400">
              Risk level:{" "}
              <span className="font-semibold text-slate-200">{insight.risk}</span>
            </span>
          </div>
        </div>
      </motion.div>

      {/* Sentiment */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="rounded-2xl border border-white/5 bg-white/[0.02] p-5"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-slate-400 font-semibold">
            <Newspaper className="h-4 w-4" />
            News Sentiment
          </div>
          <span
            className={
              "text-xs font-semibold px-2.5 py-1 rounded-full " +
              (sentiment.label === "Bullish"
                ? "bg-emerald-500/15 text-emerald-300"
                : sentiment.label === "Bearish"
                  ? "bg-rose-500/15 text-rose-300"
                  : "bg-amber-500/15 text-amber-300")
            }
          >
            {sentiment.label} · {sentiment.score > 0 ? "+" : ""}
            {sentiment.score.toFixed(2)}
          </span>
        </div>

        <div className="mt-4 space-y-2">
          {sentiment.headlines.slice(0, 5).map((h, i) => (
            <div
              key={i}
              className="flex items-start gap-3 rounded-lg border border-white/5 bg-white/[0.02] p-3"
            >
              <div
                className={
                  "mt-0.5 h-2 w-2 rounded-full shrink-0 " +
                  (h.sentiment > 0.1
                    ? "bg-emerald-400"
                    : h.sentiment < -0.1
                      ? "bg-rose-400"
                      : "bg-slate-400")
                }
              />
              <div className="flex-1 min-w-0">
                <div className="text-sm text-slate-200 leading-snug">{h.title}</div>
                <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-2">
                  <span>{h.source}</span>
                  <span>·</span>
                  <span>
                    sentiment {h.sentiment > 0 ? "+" : ""}
                    {h.sentiment.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
