import { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, Mail, Lock, User as UserIcon, Sparkles, Activity, LineChart, Shield } from "lucide-react";
import { login, signup } from "../lib/auth";
import type { User } from "../types";

interface Props {
  onAuth: (u: User) => void;
}

export default function Login({ onAuth }: Props) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("demo@stockoracle.ai");
  const [password, setPassword] = useState("demo1234");
  const [name, setName] = useState("Demo Trader");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const user = mode === "login" ? await login(email, password) : await signup(email, password, name);
      onAuth(user);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-100 overflow-hidden relative">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-30">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(99,102,241,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.15) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
      </div>
      {/* Gradient blobs */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl" />
      <div className="absolute top-1/3 -right-32 w-96 h-96 bg-fuchsia-600/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />

      <div className="relative grid lg:grid-cols-2 min-h-screen">
        {/* Left: Brand showcase */}
        <div className="hidden lg:flex flex-col justify-between p-12 border-r border-white/5">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold tracking-tight">StockOracle AI</div>
              <div className="text-xs text-slate-400">Institutional-grade prediction engine</div>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-xs text-indigo-300">
                <Sparkles className="h-3 w-3" /> AI v4.2 · LSTM + XGBoost ensemble
              </div>
              <h1 className="mt-6 text-5xl font-bold leading-tight tracking-tight">
                Predict the market<br />
                <span className="bg-gradient-to-r from-indigo-400 via-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
                  before it moves.
                </span>
              </h1>
              <p className="mt-4 text-slate-400 max-w-md">
                Real-time OHLCV streaming, 7 technical indicators, 7 ML/DL models, and AI-powered
                sentiment fusion — all in a single unified dashboard.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: LineChart, label: "7 ML Models", sub: "LR, RF, XGB, LSTM, GRU, ARIMA" },
                { icon: Activity, label: "Live Tickers", sub: "NASDAQ, NYSE, NSE, BSE" },
                { icon: Sparkles, label: "AI Sentiment", sub: "News-driven bias correction" },
                { icon: Shield, label: "JWT Secured", sub: "End-to-end encrypted sessions" },
              ].map((f) => (
                <motion.div
                  key={f.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-white/5 bg-white/[0.02] p-4 backdrop-blur"
                >
                  <f.icon className="h-5 w-5 text-indigo-400 mb-2" />
                  <div className="text-sm font-semibold">{f.label}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{f.sub}</div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="text-xs text-slate-600">
            © 2026 StockOracle AI · For research & educational purposes. Not financial advice.
          </div>
        </div>

        {/* Right: Auth form */}
        <div className="flex items-center justify-center p-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md"
          >
            <div className="lg:hidden flex items-center gap-3 mb-8">
              <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <div className="text-xl font-bold">StockOracle AI</div>
            </div>

            <h2 className="text-3xl font-bold">
              {mode === "login" ? "Welcome back" : "Create your account"}
            </h2>
            <p className="text-slate-400 mt-2 text-sm">
              {mode === "login"
                ? "Sign in to access your prediction dashboard."
                : "Start predicting stock prices in seconds."}
            </p>

            <form onSubmit={handleSubmit} className="mt-8 space-y-4">
              {mode === "signup" && (
                <div>
                  <label className="text-xs font-medium text-slate-400 mb-1.5 block">Full name</label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-indigo-400 focus:bg-white/10 transition"
                      placeholder="Jane Doe"
                    />
                  </div>
                </div>
              )}
              <div>
                <label className="text-xs font-medium text-slate-400 mb-1.5 block">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-indigo-400 focus:bg-white/10 transition"
                    placeholder="you@example.com"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-400 mb-1.5 block">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-indigo-400 focus:bg-white/10 transition"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className="rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm px-4 py-2.5">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-lg bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500 py-3 font-semibold text-white shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 transition disabled:opacity-60"
              >
                {loading ? "Authenticating…" : mode === "login" ? "Sign in to dashboard" : "Create account"}
              </button>

              <div className="text-center text-sm text-slate-400">
                {mode === "login" ? "New here?" : "Already have an account?"}{" "}
                <button
                  type="button"
                  onClick={() => setMode(mode === "login" ? "signup" : "login")}
                  className="text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  {mode === "login" ? "Create an account" : "Sign in"}
                </button>
              </div>
            </form>

            <div className="mt-6 rounded-lg border border-white/5 bg-white/[0.02] p-4 text-xs text-slate-400">
              <div className="font-semibold text-slate-300 mb-1">Demo credentials</div>
              Email: <span className="text-slate-200">demo@stockoracle.ai</span> · Password:{" "}
              <span className="text-slate-200">demo1234</span>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
