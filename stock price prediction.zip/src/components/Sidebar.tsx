import type { AppView } from "../types";
import {
  LayoutDashboard,
  Brain,
  LineChart as LineIcon,
  Wallet,
  FlaskConical,
  Server,
  Settings,
  TrendingUp,
  LogOut,
} from "lucide-react";
// TrendingUp is reused as the Compare icon; the brand logo also uses it.

interface Props {
  view: AppView;
  onChange: (v: AppView) => void;
  onLogout: () => void;
  userName: string;
}

const items: { id: AppView; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "models", label: "Model Arena", icon: Brain },
  { id: "forecast", label: "Forecasting", icon: LineIcon },
  { id: "compare", label: "Compare Stocks", icon: TrendingUp },
  { id: "portfolio", label: "Portfolio", icon: Wallet },
  { id: "training", label: "Training Lab", icon: FlaskConical },
  { id: "backend", label: "Backend API", icon: Server },
  { id: "settings", label: "Settings", icon: Settings },
];

export default function Sidebar({ view, onChange, onLogout, userName }: Props) {
  return (
    <aside className="hidden md:flex w-64 shrink-0 flex-col border-r border-white/5 bg-[#0b1020]/80 backdrop-blur-xl">
      <div className="p-5 border-b border-white/5 flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
          <TrendingUp className="h-5 w-5 text-white" />
        </div>
        <div>
          <div className="font-bold tracking-tight">StockOracle AI</div>
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">v4.2 · Pro</div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {items.map((it) => {
          const active = view === it.id;
          return (
            <button
              key={it.id}
              onClick={() => onChange(it.id)}
              className={
                "w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition " +
                (active
                  ? "bg-gradient-to-r from-indigo-500/20 to-fuchsia-500/10 text-white border border-indigo-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5")
              }
            >
              <it.icon className={"h-4 w-4 " + (active ? "text-indigo-300" : "")} />
              {it.label}
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-white/5">
        <div className="rounded-xl bg-white/[0.03] border border-white/5 p-3 mb-2">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center font-semibold text-white text-sm">
              {userName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{userName}</div>
              <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live session
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-400 hover:text-white hover:bg-white/5 transition"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
