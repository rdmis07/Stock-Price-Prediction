import { useEffect, useMemo, useState } from "react";
import Landing from "./components/Landing";
import Login from "./components/Login";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import ModelArena from "./components/ModelArena";
import ForecastPanel from "./components/ForecastPanel";
import CompareStocks from "./components/CompareStocks";
import Portfolio from "./components/Portfolio";
import TrainingLab from "./components/TrainingLab";
import BackendCode from "./components/BackendCode";
import SettingsView from "./components/SettingsView";
import Chatbot from "./components/Chatbot";
import { getCurrentUser, logout } from "./lib/auth";
import { generateStockData, fetchLiveStockData, getTickerName } from "./lib/stockData";
import { computeAllIndicators } from "./lib/indicators";
import { runAllModels } from "./lib/models";
import type { AppView, PortfolioItem, StockCandle, TimeRange, User } from "./types";
import { Menu, X, Loader2 } from "lucide-react";

type Stage = "landing" | "auth" | "app";

export default function App() {
  const [stage, setStage] = useState<Stage>("landing");
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<AppView>("dashboard");
  const [symbol, setSymbol] = useState("AAPL");
  const [range, setRange] = useState<TimeRange>("1Y");
  const [candles, setCandles] = useState<StockCandle[]>([]);
  const [loading, setLoading] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [liveMode, setLiveMode] = useState(false);

  const [portfolio, setPortfolio] = useState<PortfolioItem[]>(() => {
    try {
      const s = localStorage.getItem("stockoracle.portfolio");
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("stockoracle.portfolio", JSON.stringify(portfolio));
  }, [portfolio]);

  // Check existing session
  useEffect(() => {
    const existing = getCurrentUser();
    if (existing) {
      setUser(existing);
      setStage("app");
    }
  }, []);

  // Load candles whenever symbol / range / liveMode / user changes
  useEffect(() => {
    if (stage !== "app" || !user) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      const data = liveMode
        ? await fetchLiveStockData(symbol, range)
        : generateStockData(symbol, range);
      if (!cancelled) {
        setCandles(data);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [symbol, range, liveMode, stage, user]);

  const models = useMemo(() => (candles.length > 30 ? runAllModels(candles) : []), [candles]);
  const indicators = useMemo(
    () => (candles.length > 30 ? computeAllIndicators(candles) : null),
    [candles],
  );

  function handleAuth(u: User) {
    setUser(u);
    setStage("app");
  }

  function handleLogout() {
    logout();
    setUser(null);
    setStage("landing");
  }

  // ---------- LANDING ----------
  if (stage === "landing") {
    return <Landing onGetStarted={() => setStage("auth")} />;
  }

  // ---------- AUTH ----------
  if (stage === "auth" || !user) {
    return (
      <Login
        onAuth={handleAuth}
      />
    );
  }

  // ---------- APP ----------
  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-100 flex">
      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/70 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <div
        className={
          "md:static fixed top-0 left-0 h-full z-50 transition-transform " +
          (mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0")
        }
      >
        <Sidebar
          view={view}
          onChange={(v) => {
            setView(v);
            setMobileOpen(false);
          }}
          onLogout={handleLogout}
          userName={user.name}
        />
      </div>

      <div className="flex-1 min-w-0 flex flex-col">
        <div className="md:hidden h-14 border-b border-white/5 bg-[#0b1020] flex items-center justify-between px-4">
          <button onClick={() => setMobileOpen(true)} className="p-2 rounded-lg hover:bg-white/5">
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <div className="font-bold">StockOracle AI</div>
          <button
            onClick={() => setStage("landing")}
            className="text-xs text-slate-400 hover:text-white"
          >
            Home
          </button>
        </div>

        <Header
          symbol={symbol}
          onSymbolChange={setSymbol}
          onRefresh={() => setCandles(generateStockData(symbol, range))}
          refreshing={loading}
        />

        <div className="border-b border-white/5 bg-[#0b1020]/50 px-4 md:px-6 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-4 flex-wrap">
            <button
              onClick={() => setStage("landing")}
              className="text-slate-400 hover:text-white transition"
            >
              ← Home
            </button>
            <span className="text-slate-400">
              Viewing: <span className="font-mono text-slate-200">{symbol}</span> ·{" "}
              {getTickerName(symbol)}
            </span>
            <span className="text-slate-500">
              {candles.length} bars · {range}
            </span>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-slate-400">Live data</span>
            <button
              onClick={() => setLiveMode((v) => !v)}
              className={
                "relative h-5 w-9 rounded-full transition " + (liveMode ? "bg-emerald-500" : "bg-white/10")
              }
            >
              <span
                className={
                  "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition " +
                  (liveMode ? "left-4" : "left-0.5")
                }
              />
            </button>
          </label>
        </div>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {loading ? (
            <div className="h-96 flex items-center justify-center text-slate-400">
              <Loader2 className="h-6 w-6 animate-spin mr-2" /> Loading {symbol}…
            </div>
          ) : (
            <>
              {view === "dashboard" && (
                <Dashboard
                  candles={candles}
                  symbol={symbol}
                  range={range}
                  onRangeChange={setRange}
                  onNavigate={setView}
                />
              )}
              {view === "models" && <ModelArena models={models} />}
              {view === "forecast" && (
                <ForecastPanel candles={candles} models={models} symbol={symbol} />
              )}
              {view === "compare" && <CompareStocks primarySymbol={symbol} />}
              {view === "portfolio" && (
                <Portfolio portfolio={portfolio} setPortfolio={setPortfolio} />
              )}
              {view === "training" && (
                <TrainingLab
                  symbol={symbol}
                  onTrained={() => setCandles(generateStockData(symbol, range))}
                />
              )}
              {view === "backend" && <BackendCode />}
              {view === "settings" && (
                <SettingsView darkMode={true} setDarkMode={() => {}} email={user.email} />
              )}
            </>
          )}
        </main>
      </div>

      {/* AI Chatbot — always visible when logged in */}
      {candles.length > 0 && indicators && (
        <Chatbot
          symbol={symbol}
          candles={candles}
          models={models}
          indicators={indicators}
        />
      )}
    </div>
  );
}
