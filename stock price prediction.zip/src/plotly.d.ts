declare module "react-plotly.js/factory" {
  import { ComponentType } from "react";
  export default function createPlotlyComponent(plotly: unknown): ComponentType<PlotParams>;
  export interface PlotParams {
    data: Plotly.Data[];
    layout?: Partial<Plotly.Layout>;
    config?: Partial<Plotly.Config>;
    useResizeHandler?: boolean;
    style?: React.CSSProperties;
    className?: string;
  }
}

declare module "react-plotly.js" {
  import { Component } from "react";
  export interface PlotParams {
    data: Plotly.Data[];
    layout?: Partial<Plotly.Layout>;
    config?: Partial<Plotly.Config>;
    useResizeHandler?: boolean;
    style?: React.CSSProperties;
    className?: string;
    onInitialized?: (figure: Readonly<{ data: Plotly.Data[]; layout: Plotly.Layout }>, graphDiv: HTMLElement) => void;
    onUpdate?: (figure: Readonly<{ data: Plotly.Data[]; layout: Plotly.Layout }>, graphDiv: HTMLElement) => void;
  }
  export default class Plot extends Component<PlotParams> {}
}

declare namespace Plotly {
  interface Data {
    [key: string]: unknown;
  }
  interface Layout {
    [key: string]: unknown;
  }
  interface Config {
    [key: string]: unknown;
  }
}
