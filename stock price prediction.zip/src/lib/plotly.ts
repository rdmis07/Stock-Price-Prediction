// ============================================================================
// Lightweight Plotly wrapper.
// Plotly itself is loaded via CDN in index.html (window.Plotly) to keep the
// Vite bundle small. We use react-plotly.js's factory to bind it.
// ============================================================================
import createPlotlyComponent from "react-plotly.js/factory";

declare global {
  interface Window {
    Plotly: unknown;
  }
}

// Fallback: if CDN hasn't loaded, create a no-op to avoid crash.
const PlotlyGlobal: unknown =
  typeof window !== "undefined" && window.Plotly
    ? window.Plotly
    : {
        newPlot: () => Promise.resolve(),
        react: () => Promise.resolve(),
      };

const Plot = createPlotlyComponent(PlotlyGlobal as never);
export default Plot;
