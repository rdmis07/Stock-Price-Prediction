// ============================================================================
// Prediction history — persisted to localStorage so users can audit past calls.
// ============================================================================

import type { PredictionHistoryEntry } from "../types";

const KEY = "stockoracle.predictions";

export function loadHistory(): PredictionHistoryEntry[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveHistory(entries: PredictionHistoryEntry[]) {
  localStorage.setItem(KEY, JSON.stringify(entries.slice(-200)));
}

export function addHistory(entry: Omit<PredictionHistoryEntry, "id" | "timestamp">) {
  const list = loadHistory();
  const full: PredictionHistoryEntry = {
    ...entry,
    id: Math.random().toString(36).slice(2),
    timestamp: Date.now(),
  };
  const next = [full, ...list];
  saveHistory(next);
  return next;
}

export function clearHistory() {
  localStorage.removeItem(KEY);
}
