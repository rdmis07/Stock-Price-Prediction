// ============================================================================
// Technical indicator library: SMA, EMA, RSI, MACD, Bollinger, Volatility, Momentum
// Pure TypeScript implementations (no external dependency).
// ============================================================================

import type { StockCandle, TechnicalIndicators } from "../types";

// ---------- Simple Moving Average ----------
export function sma(values: number[], period: number): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  if (values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  out[period - 1] = sum / period;
  for (let i = period; i < values.length; i++) {
    sum += values[i] - values[i - period];
    out[i] = sum / period;
  }
  return out;
}

// ---------- Exponential Moving Average ----------
export function ema(values: number[], period: number): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  out[period - 1] = sum / period;
  for (let i = period; i < values.length; i++) {
    out[i] = values[i] * k + out[i - 1] * (1 - k);
  }
  return out;
}

// ---------- Relative Strength Index ----------
export function rsi(values: number[], period = 14): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  if (values.length <= period) return out;
  let gains = 0;
  let losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = values[i] - values[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const diff = values[i] - values[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

// ---------- MACD (12, 26, 9) ----------
export function macd(values: number[], fast = 12, slow = 26, signalPeriod = 9) {
  const fastEma = ema(values, fast);
  const slowEma = ema(values, slow);
  const macdLine: number[] = values.map((_, i) =>
    isNaN(fastEma[i]) || isNaN(slowEma[i]) ? NaN : fastEma[i] - slowEma[i],
  );
  // Signal = EMA9 of valid macdLine entries
  const startIdx = macdLine.findIndex((v) => !isNaN(v));
  const signal: number[] = new Array(values.length).fill(NaN);
  if (startIdx >= 0) {
    const valid = macdLine.slice(startIdx);
    const sig = ema(valid, signalPeriod);
    for (let i = 0; i < sig.length; i++) signal[startIdx + i] = sig[i];
  }
  const histogram = values.map((_, i) =>
    isNaN(macdLine[i]) || isNaN(signal[i]) ? NaN : macdLine[i] - signal[i],
  );
  return { macd: macdLine, signal, histogram };
}

// ---------- Bollinger Bands (20, 2σ) ----------
export function bollinger(values: number[], period = 20, mult = 2) {
  const middle = sma(values, period);
  const upper: number[] = new Array(values.length).fill(NaN);
  const lower: number[] = new Array(values.length).fill(NaN);
  for (let i = period - 1; i < values.length; i++) {
    let sum = 0;
    for (let j = 0; j < period; j++) {
      sum += Math.pow(values[i - j] - middle[i], 2);
    }
    const sd = Math.sqrt(sum / period);
    upper[i] = middle[i] + mult * sd;
    lower[i] = middle[i] - mult * sd;
  }
  return { upper, middle, lower };
}

// ---------- Rolling Volatility (σ of log returns over N days) ----------
export function rollingVolatility(values: number[], period = 20) {
  const out: number[] = new Array(values.length).fill(NaN);
  for (let i = period; i < values.length; i++) {
    const rets: number[] = [];
    for (let j = i - period + 1; j <= i; j++) {
      rets.push(Math.log(values[j] / values[j - 1]));
    }
    const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
    const variance = rets.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / rets.length;
    out[i] = Math.sqrt(variance) * Math.sqrt(252); // annualized
  }
  return out;
}

// ---------- Momentum (Rate of Change over N days) ----------
export function momentum(values: number[], period = 10) {
  const out: number[] = new Array(values.length).fill(NaN);
  for (let i = period; i < values.length; i++) {
    out[i] = ((values[i] - values[i - period]) / values[i - period]) * 100;
  }
  return out;
}

// ---------- Aggregate all indicators ----------
export function computeAllIndicators(candles: StockCandle[]): TechnicalIndicators {
  const closes = candles.map((c) => c.close);
  return {
    sma20: sma(closes, 20),
    sma50: sma(closes, 50),
    ema20: ema(closes, 20),
    rsi: rsi(closes, 14),
    macd: macd(closes),
    bollinger: bollinger(closes),
    volatility: rollingVolatility(closes),
    momentum: momentum(closes),
  };
}

// ---------- Helpers: latest non-NaN value ----------
export function lastValid(arr: number[]): number {
  for (let i = arr.length - 1; i >= 0; i--) if (!isNaN(arr[i])) return arr[i];
  return NaN;
}
