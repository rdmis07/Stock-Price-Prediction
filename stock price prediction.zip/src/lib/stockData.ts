// ============================================================================
// Deterministic synthetic stock data generator.
// Produces realistic OHLCV data so the app works offline / without CORS.
// A live-data fetcher is also exported (best-effort via AllOrigins proxy).
// ============================================================================

import type { StockCandle, TimeRange } from "../types";

// Deterministic PRNG (Mulberry32) so each ticker always produces the same series.
function seedFromSymbol(symbol: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < symbol.length; i++) {
    h ^= symbol.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Base prices (approximate) so tickers look familiar.
const BASE_PRICES: Record<string, number> = {
  AAPL: 185,
  MSFT: 415,
  GOOGL: 170,
  AMZN: 180,
  NVDA: 880,
  META: 490,
  TSLA: 250,
  NFLX: 620,
  AMD: 165,
  INTC: 32,
  "RELIANCE.NS": 2950,
  "TCS.NS": 4100,
  "INFY.NS": 1850,
  "HDFCBANK.NS": 1700,
  "WIPRO.NS": 560,
};

export const POPULAR_TICKERS = Object.keys(BASE_PRICES);

export function getTickerName(symbol: string): string {
  const names: Record<string, string> = {
    AAPL: "Apple Inc.",
    MSFT: "Microsoft Corp.",
    GOOGL: "Alphabet Inc.",
    AMZN: "Amazon.com Inc.",
    NVDA: "NVIDIA Corp.",
    META: "Meta Platforms",
    TSLA: "Tesla Inc.",
    NFLX: "Netflix Inc.",
    AMD: "Advanced Micro Devices",
    INTC: "Intel Corp.",
    "RELIANCE.NS": "Reliance Industries",
    "TCS.NS": "Tata Consultancy Services",
    "INFY.NS": "Infosys Ltd.",
    "HDFCBANK.NS": "HDFC Bank Ltd.",
    "WIPRO.NS": "Wipro Ltd.",
  };
  return names[symbol] ?? symbol;
}

function rangeToDays(range: TimeRange): number {
  switch (range) {
    case "1M":
      return 22;
    case "3M":
      return 66;
    case "6M":
      return 132;
    case "1Y":
      return 252;
    case "2Y":
      return 504;
    case "5Y":
      return 1260;
  }
}

/**
 * Generate realistic OHLCV data using Geometric Brownian Motion.
 * Deterministic per-symbol so repeated calls produce identical series.
 */
export function generateStockData(symbol: string, range: TimeRange = "1Y"): StockCandle[] {
  const days = rangeToDays(range);
  const rand = mulberry32(seedFromSymbol(symbol));
  const basePrice = BASE_PRICES[symbol] ?? 100 + (seedFromSymbol(symbol) % 500);

  const data: StockCandle[] = [];
  let price = basePrice * (0.55 + rand() * 0.25); // start lower to allow growth
  const drift = 0.00045; // slight upward bias
  const vol = 0.018 + (rand() * 0.015);

  // End date = today
  const end = new Date();
  end.setHours(0, 0, 0, 0);

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(end);
    d.setDate(end.getDate() - i);

    // Skip weekends (approximation)
    const dow = d.getDay();
    if (dow === 0 || dow === 6) continue;

    // GBM step with occasional jumps
    const jump = rand() < 0.03 ? (rand() - 0.5) * 0.06 : 0;
    const shock = drift + vol * gauss(rand) + jump;
    price = Math.max(1, price * (1 + shock));

    const dayVol = vol * (0.6 + rand() * 0.8);
    const open = price * (1 + (rand() - 0.5) * dayVol * 0.5);
    const close = price;
    const high = Math.max(open, close) * (1 + rand() * dayVol * 0.6);
    const low = Math.min(open, close) * (1 - rand() * dayVol * 0.6);
    const baseVol = 20_000_000 + (seedFromSymbol(symbol) % 80_000_000);
    const volume = Math.round(baseVol * (0.5 + rand() * 1.2));

    data.push({
      date: d.toISOString().slice(0, 10),
      open: round2(open),
      high: round2(high),
      low: round2(low),
      close: round2(close),
      volume,
    });
  }
  return data;
}

function gauss(rand: () => number): number {
  // Box-Muller transform
  const u = Math.max(1e-9, rand());
  const v = Math.max(1e-9, rand());
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ---------------- Live data (best-effort) ----------------
// Uses the AllOrigins CORS proxy. Falls back to synthetic data on failure.
export async function fetchLiveStockData(
  symbol: string,
  range: TimeRange = "1Y",
): Promise<StockCandle[]> {
  try {
    const period = range === "1M" ? "1mo" : range === "3M" ? "3mo" : range === "6M" ? "6mo" : range === "1Y" ? "1y" : range === "2Y" ? "2y" : "5y";
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(
      symbol,
    )}?range=${period}&interval=1d&includePrePost=false`;
    const proxied = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    let res: Response;
    try {
      res = await fetch(proxied, { signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok) throw new Error("HTTP " + res.status);
    const json = await res.json();
    const result = json?.chart?.result?.[0];
    if (!result) throw new Error("Empty chart result");
    const ts: number[] = result.timestamp;
    const q = result.indicators.quote[0];
    const out: StockCandle[] = [];
    for (let i = 0; i < ts.length; i++) {
      if (q.close[i] == null) continue;
      out.push({
        date: new Date(ts[i] * 1000).toISOString().slice(0, 10),
        open: round2(q.open[i] ?? q.close[i]),
        high: round2(q.high[i] ?? q.close[i]),
        low: round2(q.low[i] ?? q.close[i]),
        close: round2(q.close[i]),
        volume: Math.round(q.volume[i] ?? 0),
      });
    }
    if (out.length < 20) throw new Error("Too few data points");
    return out;
  } catch {
    return generateStockData(symbol, range);
  }
}
