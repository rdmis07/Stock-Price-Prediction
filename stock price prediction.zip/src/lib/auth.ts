// ============================================================================
// Client-side authentication simulation (JWT-style token in localStorage).
// In production, calls would go to /api/auth/login & /api/auth/signup.
// ============================================================================

import type { User } from "../types";

const USERS_KEY = "stockoracle.users";
const SESSION_KEY = "stockoracle.session";

type StoredUser = { email: string; name: string; password: string };

function loadUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveUsers(u: StoredUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(u));
}

function fakeJwt(email: string): string {
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = btoa(
    JSON.stringify({ email, iat: Date.now(), exp: Date.now() + 1000 * 60 * 60 * 24 * 7 }),
  );
  const sig = btoa(email + ":" + Date.now()).slice(0, 24);
  return `${header}.${payload}.${sig}`;
}

export async function signup(email: string, password: string, name: string): Promise<User> {
  await new Promise((r) => setTimeout(r, 500));
  if (!email || !password || !name) throw new Error("All fields are required");
  if (password.length < 4) throw new Error("Password must be at least 4 characters");
  const users = loadUsers();
  if (users.some((u) => u.email === email)) throw new Error("Email already registered");
  users.push({ email, name, password });
  saveUsers(users);
  const user: User = { email, name, token: fakeJwt(email) };
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return user;
}

export async function login(email: string, password: string): Promise<User> {
  await new Promise((r) => setTimeout(r, 500));
  const users = loadUsers();
  const u = users.find((x) => x.email === email && x.password === password);
  if (!u) throw new Error("Invalid email or password");
  const user: User = { email: u.email, name: u.name, token: fakeJwt(u.email) };
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return user;
}

export function logout() {
  localStorage.removeItem(SESSION_KEY);
}

export function getCurrentUser(): User | null {
  try {
    const s = localStorage.getItem(SESSION_KEY);
    return s ? (JSON.parse(s) as User) : null;
  } catch {
    return null;
  }
}

// Demo account auto-bootstrap
export function ensureDemoUser(): User {
  const existing = getCurrentUser();
  if (existing) return existing;
  const users = loadUsers();
  if (!users.some((u) => u.email === "demo@stockoracle.ai")) {
    users.push({ email: "demo@stockoracle.ai", name: "Demo Trader", password: "demo1234" });
    saveUsers(users);
  }
  const user: User = {
    email: "demo@stockoracle.ai",
    name: "Demo Trader",
    token: fakeJwt("demo@stockoracle.ai"),
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return user;
}
