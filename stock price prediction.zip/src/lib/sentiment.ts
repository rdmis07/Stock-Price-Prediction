// ============================================================================
// Deterministic news sentiment generator.
// In production this would call a FinBERT / NewsAPI / GPT endpoint.
// ============================================================================

import type { Sentiment } from "../types";

const SOURCES = ["Bloomberg", "Reuters", "CNBC", "MarketWatch", "Yahoo Finance", "WSJ"];

const BULLISH_HEADLINES = [
  "{SYM} beats earnings expectations, raises guidance",
  "Analysts upgrade {SYM} to Overweight, lift price target",
  "Institutional investors accumulate {SYM} shares",
  "{SYM} unveils AI-driven product line, stock surges",
  "Strong demand signals lift {SYM} outlook",
];

const BEARISH_HEADLINES = [
  "{SYM} misses quarterly revenue estimates",
  "Regulatory scrutiny clouds {SYM} outlook",
  "Insiders offload {SYM} shares amid slowdown fears",
  "Supply chain pressure weighs on {SYM}",
  "Analysts trim {SYM} target citing margin risk",
];

const NEUTRAL_HEADLINES = [
  "{SYM} holds steady ahead of Fed decision",
  "Mixed signals for {SYM} as market digests data",
  "{SYM} announces board reshuffle",
  "Options activity in {SYM} remains muted",
];

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function seededRand(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function generateSentiment(symbol: string, lastChangePct: number): Sentiment {
  const rand = seededRand(hashStr(symbol));
  // Bias based on price momentum
  const bias = Math.max(-1, Math.min(1, lastChangePct / 3));
  const headlines: Sentiment["headlines"] = [];
  let total = 0;
  for (let i = 0; i < 6; i++) {
    const r = rand();
    const pool =
      r < 0.33 + bias * 0.2
        ? BULLISH_HEADLINES
        : r > 0.66 + bias * 0.2
          ? BEARISH_HEADLINES
          : NEUTRAL_HEADLINES;
    const tpl = pool[Math.floor(rand() * pool.length)];
    const title = tpl.replace("{SYM}", symbol);
    let s: number;
    if (pool === BULLISH_HEADLINES) s = 0.4 + rand() * 0.55;
    else if (pool === BEARISH_HEADLINES) s = -0.4 - rand() * 0.55;
    else s = (rand() - 0.5) * 0.3;
    headlines.push({
      title,
      sentiment: Math.round(s * 100) / 100,
      source: SOURCES[Math.floor(rand() * SOURCES.length)],
    });
    total += s;
  }
  const score = Math.round((total / headlines.length) * 100) / 100;
  const label: Sentiment["label"] =
    score > 0.2 ? "Bullish" : score < -0.2 ? "Bearish" : "Neutral";
  return { score, label, headlines };
}
