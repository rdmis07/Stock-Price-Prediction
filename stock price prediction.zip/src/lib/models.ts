// ============================================================================
// ML / DL model simulators.
// Real ML (Linear Regression, k-NN style), plus realistic simulations of
// Random Forest, XGBoost, LSTM, GRU, ARIMA. Each model returns forecasts and
// evaluation metrics computed on a hold-out window.
// ============================================================================

import type { ModelMetrics, ModelPrediction, StockCandle } from "../types";
import { ema, sma } from "./indicators";

// ---------------- Utility ----------------
function metricsFromErrors(errors: number[], yTrue: number[], yPred: number[]): ModelMetrics {
  const n = errors.length;
  const mae = errors.reduce((a, b) => a + Math.abs(b), 0) / n;
  const mse = errors.reduce((a, b) => a + b * b, 0) / n;
  const rmse = Math.sqrt(mse);
  const meanY = yTrue.reduce((a, b) => a + b, 0) / n;
  const ssTot = yTrue.reduce((a, b) => a + Math.pow(b - meanY, 2), 0);
  const ssRes = errors.reduce((a, b) => a + b * b, 0);
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot;
  // Directional accuracy
  let correct = 0;
  for (let i = 1; i < yTrue.length; i++) {
    const actual = yTrue[i] - yTrue[i - 1];
    const pred = yPred[i] - yPred[i - 1];
    if (Math.sign(actual) === Math.sign(pred)) correct++;
  }
  const accuracy = (correct / (yTrue.length - 1)) * 100;
  return {
    mae: round(mae),
    mse: round(mse),
    rmse: round(rmse),
    r2: round(r2, 4),
    accuracy: round(accuracy, 1),
  };
}

function round(n: number, d = 2): number {
  const f = Math.pow(10, d);
  return Math.round(n * f) / f;
}

// ---------------- Linear Regression (OLS) ----------------
function linearRegressionForecast(series: number[], horizon: number) {
  const n = series.length;
  const xs = Array.from({ length: n }, (_, i) => i);
  const mx = xs.reduce((a, b) => a + b, 0) / n;
  const my = series.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - mx) * (series[i] - my);
    den += (xs[i] - mx) ** 2;
  }
  const slope = den === 0 ? 0 : num / den;
  const intercept = my - slope * mx;
  const fitted = xs.map((x) => slope * x + intercept);
  const forecast: number[] = [];
  for (let i = 0; i < horizon; i++) forecast.push(slope * (n + i) + intercept);
  return { fitted, forecast, slope, intercept };
}

// ---------------- Random Forest / XGBoost / LSTM / GRU simulation ----------------
// Each "model" uses a different smoothing + trend + noise recipe to produce
// a distinct forecast. Metrics are measured on a real hold-out slice.

interface ModelRecipe {
  name: string;
  type: "ML" | "DL" | "Statistical";
  color: string;
  /** Given a training series, produce a one-step-ahead prediction function
   *  that predicts y[t] given the history up to t-1. */
  predictOne: (history: number[]) => number;
  /** Confidence base (0..1); will be modulated by R². */
  baseConfidence: number;
}

function last(arr: number[], n: number): number[] {
  return arr.slice(-n);
}

const recipes: ModelRecipe[] = [
  {
    name: "Linear Regression",
    type: "ML",
    color: "#60a5fa",
    predictOne: (h) => {
      const { slope, intercept } = linearRegressionForecast(h, 1);
      return slope * h.length + intercept;
    },
    baseConfidence: 0.55,
  },
  {
    name: "Random Forest",
    type: "ML",
    color: "#34d399",
    predictOne: (h) => {
      // Ensemble of recent SMAs + momentum
      const s10 = sma(h, Math.min(10, h.length));
      const s20 = sma(h, Math.min(20, h.length));
      const mom = h[h.length - 1] - h[Math.max(0, h.length - 6)];
      return (last(s10, 1)[0] * 0.5 + last(s20, 1)[0] * 0.5) + mom * 0.05;
    },
    baseConfidence: 0.68,
  },
  {
    name: "Decision Tree",
    type: "ML",
    color: "#fbbf24",
    predictOne: (h) => {
      const last5 = last(h, 5);
      const trend = last5[last5.length - 1] - last5[0];
      return h[h.length - 1] + trend * 0.1;
    },
    baseConfidence: 0.58,
  },
  {
    name: "XGBoost",
    type: "ML",
    color: "#f472b6",
    predictOne: (h) => {
      const e = ema(h, Math.min(12, h.length));
      const trend = (h[h.length - 1] - h[Math.max(0, h.length - 10)]) / 10;
      return last(e, 1)[0] + trend * 0.6;
    },
    baseConfidence: 0.76,
  },
  {
    name: "LSTM Neural Net",
    type: "DL",
    color: "#a78bfa",
    predictOne: (h) => {
      // Simulated: double-EMA with adaptive momentum
      const e12 = ema(h, Math.min(12, h.length));
      const e26 = ema(h, Math.min(26, h.length));
      const e12Last = last(e12, 1)[0];
      const e26Last = last(e26, 1)[0];
      const mom = e12Last - e26Last;
      return e12Last + mom * 0.85;
    },
    baseConfidence: 0.82,
  },
  {
    name: "GRU Neural Net",
    type: "DL",
    color: "#c084fc",
    predictOne: (h) => {
      const e20 = ema(h, Math.min(20, h.length));
      const slope = (h[h.length - 1] - h[Math.max(0, h.length - 15)]) / 15;
      return last(e20, 1)[0] + slope * 0.9;
    },
    baseConfidence: 0.79,
  },
  {
    name: "ARIMA",
    type: "Statistical",
    color: "#fb7185",
    predictOne: (h) => {
      // AR(2) approximation on differenced series
      if (h.length < 4) return h[h.length - 1];
      const n = h.length;
      const y1 = h[n - 1] - h[n - 2];
      const y2 = h[n - 2] - h[n - 3];
      const diffPred = 0.6 * y1 + 0.25 * y2;
      return h[n - 1] + diffPred * 0.7;
    },
    baseConfidence: 0.65,
  },
  {
    name: "Prophet",
    type: "Statistical",
    color: "#22d3ee",
    predictOne: (h) => {
      // Simulates Prophet's additive trend + weekly seasonality decomposition.
      // Trend: robust linear fit on recent 60 points.
      // Seasonality: 5-day weekly cycle extracted from the full series.
      const n = h.length;
      const window = Math.min(60, n);
      const tail = h.slice(-window);
      let sx = 0,
        sy = 0,
        sxy = 0,
        sxx = 0;
      for (let i = 0; i < tail.length; i++) {
        sx += i;
        sy += tail[i];
        sxy += i * tail[i];
        sxx += i * i;
      }
      const slope = (tail.length * sxy - sx * sy) / (tail.length * sxx - sx * sx || 1);
      const intercept = (sy - slope * sx) / tail.length;
      const trend = slope * tail.length + intercept;

      // Weekly seasonality (5 trading days)
      const seasonal: number[] = [0, 0, 0, 0, 0];
      const counts = [0, 0, 0, 0, 0];
      for (let i = 5; i < n; i++) {
        const dow = i % 5;
        seasonal[dow] += h[i] - h[i - 1];
        counts[dow]++;
      }
      for (let i = 0; i < 5; i++) seasonal[i] = counts[i] ? seasonal[i] / counts[i] : 0;
      const nextDow = n % 5;

      return trend + seasonal[nextDow];
    },
    baseConfidence: 0.7,
  },
];

// ---------------- Evaluation on hold-out ----------------
function evaluateRecipe(recipe: ModelRecipe, series: number[], holdOut = 30) {
  const trainEnd = series.length - holdOut;
  const yTrue: number[] = [];
  const yPred: number[] = [];
  const errors: number[] = [];
  for (let t = trainEnd; t < series.length; t++) {
    const history = series.slice(0, t);
    const pred = recipe.predictOne(history);
    yTrue.push(series[t]);
    yPred.push(pred);
    errors.push(series[t] - pred);
  }
  const m = metricsFromErrors(errors, yTrue, yPred);
  return m;
}

// ---------------- Multi-step forecast ----------------
function multiStepForecast(recipe: ModelRecipe, series: number[], horizon: number): number[] {
  const hist = [...series];
  const out: number[] = [];
  for (let i = 0; i < horizon; i++) {
    const next = recipe.predictOne(hist);
    // Add small realistic noise
    const noise = (Math.sin(hist.length * 0.37 + i) * 0.002) * hist[hist.length - 1];
    const val = next + noise;
    out.push(round(val));
    hist.push(val);
  }
  return out;
}

// ---------------- Public API ----------------
export function runAllModels(candles: StockCandle[]): ModelPrediction[] {
  const closes = candles.map((c) => c.close);
  return recipes.map((r) => {
    const metrics = evaluateRecipe(r, closes, 30);
    const f7 = multiStepForecast(r, closes, 7);
    const f30 = multiStepForecast(r, closes, 30);
    const nextDay = f7[0];
    const lastClose = closes[closes.length - 1];
    const change = (nextDay - lastClose) / lastClose;
    let signal: "BUY" | "SELL" | "HOLD" = "HOLD";
    if (change > 0.005) signal = "BUY";
    else if (change < -0.005) signal = "SELL";
    const confidence = Math.min(
      0.99,
      Math.max(0.35, r.baseConfidence * (0.7 + Math.max(0, metrics.r2) * 0.5)),
    );
    return {
      modelName: r.name,
      modelType: r.type,
      nextDay,
      forecast7: f7,
      forecast30: f30,
      metrics,
      confidence: round(confidence, 3),
      signal,
      color: r.color,
    };
  });
}

// ---------------- Ensemble "AI" insight ----------------
export function ensembleInsight(models: ModelPrediction[], lastClose: number) {
  const votes = { BUY: 0, SELL: 0, HOLD: 0 } as Record<string, number>;
  let weightedNext = 0;
  let totalWeight = 0;
  for (const m of models) {
    const w = m.confidence;
    weightedNext += m.nextDay * w;
    totalWeight += w;
    votes[m.signal]++;
  }
  const avgNext = weightedNext / totalWeight;
  const pct = ((avgNext - lastClose) / lastClose) * 100;
  const avgConf = (totalWeight / models.length) * 100;

  let signal: "Strong Buy" | "Buy" | "Hold" | "Sell" | "Strong Sell" = "Hold";
  if (pct > 1.5) signal = "Strong Buy";
  else if (pct > 0.3) signal = "Buy";
  else if (pct < -1.5) signal = "Strong Sell";
  else if (pct < -0.3) signal = "Sell";

  const trend: "Upward" | "Downward" | "Sideways" =
    pct > 0.3 ? "Upward" : pct < -0.3 ? "Downward" : "Sideways";

  const strength = Math.min(100, Math.abs(pct) * 25);

  const reasons: string[] = [];
  if (votes.BUY > votes.SELL && votes.BUY > votes.HOLD)
    reasons.push(`${votes.BUY} of ${models.length} models signal BUY`);
  if (votes.SELL > votes.BUY && votes.SELL > votes.HOLD)
    reasons.push(`${votes.SELL} of ${models.length} models signal SELL`);
  if (pct > 0) reasons.push(`Ensemble forecasts +${pct.toFixed(2)}% over next session`);
  else if (pct < 0) reasons.push(`Ensemble forecasts ${pct.toFixed(2)}% over next session`);
  reasons.push(`Mean model confidence ${avgConf.toFixed(0)}%`);

  const risk: "Low" | "Medium" | "High" =
    avgConf > 75 ? "Low" : avgConf > 55 ? "Medium" : "High";

  return {
    trend,
    strength,
    signal,
    confidence: round(avgConf, 1),
    reasons,
    risk,
    ensembleNext: round(avgNext),
    votes,
  };
}
