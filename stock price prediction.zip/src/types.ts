// ============================================================================
// Type definitions for StockOracle AI - Stock Price Prediction System
// ============================================================================

export interface StockCandle {
  date: string;        // ISO date string
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  adjClose?: number;
}

export interface TechnicalIndicators {
  sma20: number[];
  sma50: number[];
  ema20: number[];
  rsi: number[];
  macd: {
    macd: number[];
    signal: number[];
    histogram: number[];
  };
  bollinger: {
    upper: number[];
    middle: number[];
    lower: number[];
  };
  volatility: number[];
  momentum: number[];
}

export interface ModelPrediction {
  modelName: string;
  modelType: "ML" | "DL" | "Statistical";
  nextDay: number;
  forecast7: number[];
  forecast30: number[];
  metrics: ModelMetrics;
  confidence: number;        // 0..1
  signal: "BUY" | "SELL" | "HOLD";
  color: string;
}

export interface ModelMetrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
  accuracy: number;
}

export interface Sentiment {
  score: number;             // -1 to +1
  label: "Bearish" | "Neutral" | "Bullish";
  headlines: { title: string; sentiment: number; source: string }[];
}

export interface AIInsight {
  trend: "Upward" | "Downward" | "Sideways";
  strength: number;          // 0..100
  signal: "Strong Buy" | "Buy" | "Hold" | "Sell" | "Strong Sell";
  confidence: number;        // 0..100
  reasons: string[];
  risk: "Low" | "Medium" | "High";
}

export interface PortfolioItem {
  symbol: string;
  name: string;
  shares: number;
  avgPrice: number;
  currentPrice: number;
  change: number;            // %
  value: number;
}

export interface User {
  email: string;
  name: string;
  token: string;
}

export type TimeRange = "1M" | "3M" | "6M" | "1Y" | "2Y" | "5Y";
export type ForecastHorizon = "1D" | "7D" | "30D";
export type AppView =
  | "dashboard"
  | "models"
  | "forecast"
  | "portfolio"
  | "compare"
  | "training"
  | "backend"
  | "settings";

export interface PredictionHistoryEntry {
  id: string;
  symbol: string;
  timestamp: number;
  horizon: "1D" | "7D" | "30D";
  lastClose: number;
  ensembleNext: number;
  signal: string;
  confidence: number;
  changePct: number;
}
